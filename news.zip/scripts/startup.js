
const colors = {
  reset: '\x1b[0m',
  yellow: '\x1b[38;5;220m',
  white: '\x1b[97m',
  cyan: '\x1b[38;5;117m',
  green: '\x1b[38;5;120m',
  muted: '\x1b[38;5;245m',
  violet: '\x1b[38;5;141m',
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const line = (text, color = colors.muted) => {
  console.log(`  ${color}${text}${colors.reset}`)
}

async function startConsole() {
  const start = Date.now()
  console.clear()
  console.log()

  
console.log(`
  atelier ✨ 
✨ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ✨          
   Your personal universe awaits

✨ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ✨
`)
  line('PERSONAL LIFE MANAGEMENT SYSTEM', colors.muted)
  
  line('─────────────────────────────────────────', colors.violet)
  console.log()

  const steps = [
    ['[✓] Project environment loaded', colors.green],
    ['[✓] React + Vite startup command prepared', colors.green],
    ['[>] Preparing development configuration...', colors.cyan],
    ['[>] Initializing local workspace...', colors.cyan],
    ['[>] Checking application configuration...', colors.cyan],
    ['[>] Preparing the development server...', colors.cyan],
    ['[>] Handing control to Vite...', colors.cyan],
  ]

  // Reserve 10 seconds for the animation.
  // Finish at 11 seconds from the start of the console.
  for (let i = 0; i < steps.length; i++) {
    const [message, color] = steps[i]
    line(message, color)

    const elapsed = Date.now() - start
    const nextTarget = ((i + 1) / steps.length) * 10000
    await sleep(Math.max(0, nextTarget - elapsed))
  }

 
const remaining = 11000 - (Date.now() - start)
if (remaining > 0) await sleep(remaining)

const finalSteps = [
  ['[✦] Calibrating your personal workspace...', colors.violet],
  ['[✦] Synchronizing tasks, goals & habits...', colors.cyan],
  ['[✦] Preparing your productivity interface...', colors.green],
  ['[✦] Your digital sanctuary is taking shape...', colors.yellow],
  ['[✓] ATELIER SYSTEM READY. WELCOME BACK.', colors.white],
]

for (const [message, color] of finalSteps) {
  line(message, color)
  await sleep(350)
}


  console.log()
  line('─────────────────────────────────────────', colors.violet)
  line('✦ Your space. Your pace.', colors.yellow)
  line('Launching the development server...', colors.white)
  console.log()
}

await startConsole()
