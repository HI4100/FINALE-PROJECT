# atelier. Project Guide — Viva Preparation

## Project introduction

“atelier. is a personal life management web application. It brings tasks, goals, daily habits, and notes into one workspace. The goal is to help users organise daily work and see progress without switching between separate tools.”

The product is AI-inspired in concept and interface. Do not claim a generative AI model is connected unless one has actually been integrated.

## Technology stack

- **React:** component-based interface and state management.
- **Vite:** local development server and production bundler.
- **JavaScript / JSX:** application logic and interface markup.
- **CSS:** layout, responsive behaviour, colour system, and component styling.
- **Supabase Auth:** registration, login, sessions, sign-out, and email verification.
- **localStorage:** saves workspace items in the current browser.

## Folder structure

- `src/main.jsx`: entry point; mounts the React app.
- `src/App.jsx`: coordinator; owns shared state, navigation, authentication flow, and callbacks.
- `src/components/Icon.jsx`: reusable SVG icon component.
- `src/features/overview/Overview.jsx`: daily summary and previews.
- `src/features/tasks/Tasks.jsx`: task search, list, and task form UI.
- `src/features/goals/Goals.jsx`: goal cards and progress controls.
- `src/features/habits/Habits.jsx`: habit check-in and list.
- `src/features/notes/Notes.jsx`: note editor and saved notes.
- Each feature has a matching CSS file. Feature-specific styles are moved out of the original `src/App.css`; shared and responsive rules remain there.
- `src/utils/workspaceData.js`: sample data, data loading, ID generation, and date helpers.
- `src/supabase.js`: Supabase client setup.
- `scripts/startup.js`: decorative terminal startup sequence.
- `.env.example`: documents required environment variables. Real credentials belong only in a local `.env`.

## How the app works

1. `main.jsx` mounts `App`.
2. `App` loads saved workspace data using `loadData()` from `workspaceData.js`.
3. React state holds tasks, goals, habits, notes, and daily habit check-ins.
4. Navigation selects which feature component to render.
5. `App` passes the required data and event handlers to child components through props.
6. When an item is created, completed, edited, or deleted, a handler updates React state.
7. An effect serialises workspace state as JSON and stores it under `atelier-workspace-v1` in `localStorage`.
8. On a later visit in the same browser, `loadData()` reads that JSON and restores the workspace.

## Common viva questions

**Why React?** React lets the interface be split into reusable components and update when state changes.

**What is a component?** A reusable part of the interface. For example, `Goals.jsx` renders the goals page and `Notes.jsx` renders the notes page.

**Why separate files?** It improves readability and maintenance. A change to goals can be made in the goals feature without searching through every page.

**What is a prop?** A value or function passed from a parent component to a child component. Feature components receive data and callbacks through props.

**Why keep shared state in `App.jsx`?** Several screens use the same workspace data. One source of truth prevents the overview and detail pages from keeping conflicting copies.

**What is `useState`?** It stores values that change while the app is running, such as task lists, open forms, and the selected page.

**What is `useEffect` used for?** It handles side effects such as saving data to localStorage, checking the Supabase session, and clearing temporary toast messages.

**What is `useMemo` used for?** It memoises the filtered task list based on the task data and search query.

**What is localStorage?** Browser key-value storage. This project saves workspace data as JSON. It is local to that browser/device and does not automatically sync across devices.

**Does Supabase store tasks and notes?** Not in this version. Supabase handles authentication; workspace items are saved in localStorage.

**What is Supabase authentication used for?** The app calls Supabase methods for registration, login, session lookup, OTP verification, resending a code, and sign-out.

**What is Vite?** The development server and build tool used to run the app locally and create a production bundle.

**What if saved data is missing or invalid?** `loadData()` returns sample data when there is no saved workspace and falls back to defaults if saved JSON cannot be parsed.

**How could the project be improved?** Store each user's workspace in Supabase tables, apply row-level security, sync data across devices, and add automated tests.

## 60-second explanation

“First, I created the React project with Vite. I built the main layout and designed the interface with CSS. Then I divided the workspace into feature components: Overview, Tasks, Goals, Habits, and Notes. The main App component manages shared state and navigation, and passes data and functions to each page through props. When users change their workspace, React updates the state and an effect saves the data to localStorage as JSON. Supabase is used for account authentication and email verification. I separated reusable icons, data utilities, and feature-specific styles so the project is easier to maintain and explain.”

## Be accurate in the viva

- The startup sequence is a visual terminal animation; it does not perform a real system health check.
- Workspace items are saved locally, not synced to Supabase yet.
- Do not claim AI recommendations, reminders, or cloud synchronisation unless those functions have actually been implemented and tested.
