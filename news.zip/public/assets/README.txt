ATELIER ROADMAP ART

Copy all four .webp files into:
src/assets/

Then in the JSX component file, add:
import roadmapBase from './assets/roadmap-base.webp'
import roadmapMomentum from './assets/roadmap-momentum.webp'
import roadmapProgress from './assets/roadmap-progress.webp'
import roadmapStronger from './assets/roadmap-stronger.webp'

Adjust the relative import path if the JSX file is not directly inside src/.

Inside the phases array, replace the icon fields with:
image: roadmapBase
image: roadmapMomentum
image: roadmapProgress
image: roadmapStronger

Keep each image field with its matching phase object.

Replace the artwork element inside the card with:
<div className={`atelier-phase-art phase-art-${i + 1}`}>
  <img src={phase.image} alt="" className="atelier-phase-image" />
  <span className="atelier-phase-art-label">
    PHASE {String(i + 1).padStart(2, '0')}
  </span>
</div>

Add this CSS at the bottom of App.css:
.atelier-roadmap-screen .atelier-phase-art {
  position: relative;
  overflow: hidden;
  min-height: 180px;
  padding: 0;
  background: #08090d;
}
.atelier-roadmap-screen .atelier-phase-art .atelier-phase-image {
  display: block;
  width: 100%;
  height: 180px;
  object-fit: cover;
  object-position: center;
}
.atelier-roadmap-screen .atelier-phase-art::before,
.atelier-roadmap-screen .atelier-phase-art::after {
  content: none !important;
}
.atelier-roadmap-screen .atelier-phase-emoji {
  display: none !important;
}
.atelier-roadmap-screen .atelier-phase-art-label {
  position: absolute;
  z-index: 2;
  left: 14px;
  top: 14px;
  bottom: auto;
  color: #f5d58d;
  font: 600 10px Georgia, serif;
  letter-spacing: 2px;
  padding: 5px 8px;
  border: 1px solid rgba(245, 213, 141, .55);
  border-radius: 20px;
  background: rgba(0, 0, 0, .45);
}
