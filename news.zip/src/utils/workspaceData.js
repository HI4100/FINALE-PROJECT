// Default workspace data and small data/date helpers used by atelier.

export const todayKey = () => {
  const now = new Date()
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
}

export const initialTasks = [
  { id: 1, title: "Review today's priorities", time: '09:00 AM', category: 'Planning', done: false },
  { id: 2, title: 'Complete project interface', time: '11:30 AM', category: 'Work', done: false },
  { id: 3, title: 'Study for upcoming exams', time: '02:00 PM', category: 'Study', done: false },
  { id: 4, title: 'Plan tomorrow', time: '08:00 PM', category: 'Personal', done: false },
]

export const initialGoals = [
  { id: 101, title: 'Build a consistent routine', detail: 'Make space for the things that matter.', progress: 45, target: 'This month' },
  { id: 102, title: 'Finish the project', detail: 'Turn the idea into something real.', progress: 65, target: 'This month' },
]

export const initialHabits = [
  { id: 201, title: 'Morning planning', detail: 'Start the day with intention.', icon: '☀' },
  { id: 202, title: 'Read or learn', detail: 'Make progress, even if it is small.', icon: '⌘' },
  { id: 203, title: 'Move your body', detail: 'Give yourself a little movement.', icon: '↗' },
]

export const initialNotes = [
  {
    id: 301,
    title: 'A reminder to myself',
    body: 'Progress does not have to be perfect. Start with one meaningful thing and build from there.',
    updated: todayKey(),
  },
]

export const defaultData = {
  tasks: initialTasks,
  goals: initialGoals,
  habits: initialHabits,
  notes: initialNotes,
  completedHabits: {},
}

export function loadData() {
  try {
    const saved = localStorage.getItem('atelier-workspace-v1')
    if (!saved) return defaultData
    const parsed = JSON.parse(saved)
    return {
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks : initialTasks,
      goals: Array.isArray(parsed.goals) ? parsed.goals : initialGoals,
      habits: Array.isArray(parsed.habits) ? parsed.habits : initialHabits,
      notes: Array.isArray(parsed.notes) ? parsed.notes : initialNotes,
      completedHabits: parsed.completedHabits && typeof parsed.completedHabits === 'object'
        ? parsed.completedHabits
        : {},
    }
  } catch {
    return defaultData
  }
}

export function makeId() {
  return Date.now() + Math.floor(Math.random() * 1000)
}

export function formatDate() {
  return new Intl.DateTimeFormat('en', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(new Date())
}

