import React, { useMemo, useState } from 'react';
import './Notes.css';
import heroWallpaper from '../../assets/atelier-hero-wallpaper.jpg';

const NOTE_COLORS = [
  { name: 'Gold', value: 'gold', icon: '✦' },
  { name: 'Violet', value: 'violet', icon: '✧' },
  { name: 'Blue', value: 'blue', icon: '◈' },
  { name: 'Green', value: 'green', icon: '❧' },
];

function formatNoteDate(value) {
  if (!value) return 'Recently updated';
  const parsed = new Date(`${value}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) return 'Recently updated';
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(parsed);
}

export default function Notes({
  data,
  noteFormOpen,
  setNoteFormOpen,
  editingNoteId,
  setEditingNoteId,
  noteTitle,
  setNoteTitle,
  noteBody,
  setNoteBody,
  saveNote,
  resetNoteForm,
  editNote,
  deleteNote,
  navigate,
  Icon,
}) {
  const [query, setQuery] = useState('');
  const [view, setView] = useState('Grid');
  const [activeFilter, setActiveFilter] = useState('All notes');
  const [colors, setColors] = useState({});
  const [menuId, setMenuId] = useState(null);
  const [pinned, setPinned] = useState([]);

  const notes = Array.isArray(data?.notes) ? data.notes : [];
  const visibleNotes = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...notes]
      .filter((note) => {
        const matchesSearch = !q || `${note.title || ''} ${note.body || ''}`.toLowerCase().includes(q);
        const isPinned = pinned.includes(note.id);
        const matchesFilter = activeFilter === 'All notes'
          || (activeFilter === 'Pinned' && isPinned)
          || (activeFilter === 'Recently updated' && Boolean(note.updated));
        return matchesSearch && matchesFilter;
      })
      .sort((a, b) => Number(pinned.includes(b.id)) - Number(pinned.includes(a.id)));
  }, [notes, query, activeFilter, pinned]);

  function startNewNote() {
    resetNoteForm();
    setNoteFormOpen(true);
  }

  function handleEdit(note) {
    editNote(note);
    setMenuId(null);
  }

  function handleDelete(id) {
    if (window.confirm('Delete this note? This cannot be undone.')) deleteNote(id);
    setMenuId(null);
  }

  function togglePinned(id) {
    setPinned((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
    setMenuId(null);
  }

  return (
    <main className="atelier-notes-page">
      <section className="an-hero" style={{ '--an-hero-image': `url("${heroWallpaper}")` }}>
        <div className="an-hero-shade" />
        <div className="an-hero-content">
          <span className="an-kicker"><i /> YOUR PERSONAL UNIVERSE</span>
          <h1>Notes</h1>
          <p>Capture a thought. Keep the meaning.</p>
        </div>
        <blockquote>“A little clarity<br />can change everything.”</blockquote>
      </section>

      <section className="an-toolbar">
        <label className="an-search">
          <span aria-hidden="true">⌕</span>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search your notes..." aria-label="Search notes" />
          {query && <button type="button" onClick={() => setQuery('')} aria-label="Clear search">×</button>}
          <kbd>⌘ K</kbd>
        </label>
        <div className="an-filter-tabs" aria-label="Filter notes">
          {['All notes', 'Pinned', 'Recently updated'].map((filter) => (
            <button type="button" key={filter} className={activeFilter === filter ? 'active' : ''} onClick={() => setActiveFilter(filter)}>{filter}</button>
          ))}
        </div>
        <div className="an-view-switch" aria-label="Note layout">
          <button type="button" aria-pressed={view === 'Grid'} className={view === 'Grid' ? 'active' : ''} onClick={() => setView('Grid')} title="Grid view">▦</button>
          <button type="button" aria-pressed={view === 'List'} className={view === 'List' ? 'active' : ''} onClick={() => setView('List')} title="List view">☷</button>
        </div>
        <button className="an-primary" type="button" onClick={startNewNote}><span>＋</span> New Note</button>
      </section>

      {noteFormOpen && (
        <form className="an-editor" onSubmit={saveNote}>
          <div className="an-editor-heading">
            <div><span className="an-editor-spark">✦</span><div><h2>{editingNoteId ? 'Edit your note' : 'A fresh page'}</h2><p>Give your thoughts a place to land.</p></div></div>
            <button type="button" className="an-close" onClick={resetNoteForm} aria-label="Close editor">×</button>
          </div>
          <label className="an-field-label">Title
            <input value={noteTitle} onChange={(event) => setNoteTitle(event.target.value)} placeholder="Give this note a title..." maxLength={120} required autoFocus />
          </label>
          <label className="an-field-label">Your thoughts
            <textarea value={noteBody} onChange={(event) => setNoteBody(event.target.value)} placeholder="Start writing. Ideas, plans, reflections — anything worth keeping..." rows={7} maxLength={10000} required />
          </label>
          <div className="an-editor-footer"><span>{noteBody.length} characters</span><div><button className="an-secondary" type="button" onClick={resetNoteForm}>Cancel</button><button className="an-primary" type="submit">{editingNoteId ? 'Save changes' : 'Save note'} <span>↗</span></button></div></div>
        </form>
      )}

      <div className="an-section-heading">
        <div><span className="an-section-icon">✧</span><div><h2>{activeFilter === 'All notes' ? 'Your notes' : activeFilter}</h2><p>{visibleNotes.length} {visibleNotes.length === 1 ? 'note' : 'notes'} · saved in your personal space</p></div></div>
        <span className="an-count-pill">{notes.length} TOTAL</span>
      </div>

      {visibleNotes.length ? (
        <section className={`an-notes-grid ${view === 'List' ? 'list-view' : ''}`} aria-label="Your notes">
          {visibleNotes.map((note, index) => {
            const color = colors[note.id] || NOTE_COLORS[index % NOTE_COLORS.length].value;
            const pinnedNote = pinned.includes(note.id);
            return (
              <article className={`an-note-card tone-${color}`} key={note.id}>
                <div className="an-note-card-top">
                  <span className="an-note-symbol">{NOTE_COLORS.find((item) => item.value === color)?.icon || '✦'}</span>
                  <div className="an-note-actions">
                    {pinnedNote && <span className="an-pin-label">PINNED</span>}
                    <button type="button" className="an-menu-button" aria-label={`Actions for ${note.title}`} aria-expanded={menuId === note.id} onClick={() => setMenuId(menuId === note.id ? null : note.id)}>⋮</button>
                    {menuId === note.id && <div className="an-action-menu">
                      <button type="button" onClick={() => handleEdit(note)}>Edit note</button>
                      <button type="button" onClick={() => togglePinned(note.id)}>{pinnedNote ? 'Unpin note' : 'Pin note'}</button>
                      <div className="an-color-options">{NOTE_COLORS.map((item) => <button type="button" key={item.value} title={`Use ${item.name}`} aria-label={`Use ${item.name}`} className={`an-color-dot ${item.value}`} onClick={() => { setColors((current) => ({ ...current, [note.id]: item.value })); setMenuId(null); }} />)}</div>
                      <button type="button" className="danger" onClick={() => handleDelete(note.id)}>Delete note</button>
                    </div>}
                  </div>
                </div>
                <button type="button" className="an-note-open" onClick={() => handleEdit(note)} aria-label={`Open note ${note.title}`}>
                  <h3>{note.title || 'Untitled note'}</h3>
                  <p>{note.body || 'An empty page waiting for your thoughts.'}</p>
                </button>
                <footer className="an-note-footer"><span>UPDATED {formatNoteDate(note.updated).toUpperCase()}</span><button type="button" onClick={() => handleEdit(note)}>Open note <span>↗</span></button></footer>
              </article>
            );
          })}
        </section>
      ) : (
        <section className="an-empty-state">
          <div className="an-empty-art">✧</div>
          <h2>{query ? 'No matching thoughts' : activeFilter === 'Pinned' ? 'Nothing pinned yet' : 'Your next idea starts here'}</h2>
          <p>{query ? 'Try another search term.' : activeFilter === 'Pinned' ? 'Open a note menu and pin the notes you want to keep close.' : 'Keep plans, reflections, and little sparks of inspiration in one place.'}</p>
          {!query && activeFilter !== 'Pinned' && <button className="an-primary" type="button" onClick={startNewNote}>＋ Write your first note</button>}
          {query && <button className="an-secondary" type="button" onClick={() => setQuery('')}>Clear search</button>}
        </section>
      )}

      <footer className="an-bottom-quote"><span>✦</span><p>Collect the thoughts that move you forward.</p><span className="an-bottom-stars">✧ · ✦</span></footer>
    </main>
  );
}
