import './Overview.css';

export default function Overview({
  data, profile, setup, greeting, completedTasks, taskProgress, completedHabits,
  openTasks, navigate, renderTaskList, setTaskFormOpen, renderHabitList,
  setGoalFormOpen, setNoteFormOpen, setEditingNoteId, setNoteTitle, setNoteBody,
  editNote, Icon, formatDate,
}) {
  const tasks = Array.isArray(data?.tasks) ? data.tasks : [];
  const goals = Array.isArray(data?.goals) ? data.goals : [];
  const habits = Array.isArray(data?.habits) ? data.habits : [];
  const notes = Array.isArray(data?.notes) ? data.notes : [];
  const name = profile?.name || setup?.name || 'there';
  const safeTaskProgress = Number.isFinite(taskProgress) ? taskProgress : 0;
  const habitProgress = habits.length ? Math.round((completedHabits / habits.length) * 100) : 0;
  const goalProgress = goals.length
    ? Math.round(goals.reduce((sum, goal) => sum + (Number(goal.progress) || 0), 0) / goals.length)
    : 0;
  const dateLabel = typeof formatDate === 'function'
    ? formatDate()
    : new Intl.DateTimeFormat('en', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).format(new Date());

  return (
    <main className="atelier-dashboard">
      <section className="atelier-dash-hero">
        <div className="atelier-dash-hero-art" aria-hidden="true">
          <div className="atelier-dash-planet" />
          <div className="atelier-dash-small-moon" />
          <div className="atelier-dash-hero-ridge ridge-back" />
          <div className="atelier-dash-hero-ridge ridge-front" />
          <div className="atelier-dash-silhouette"><span /></div>
          <i className="dash-star ds1">✦</i><i className="dash-star ds2">✧</i><i className="dash-star ds3">✦</i><i className="dash-star ds4">·</i>
        </div>
        <div className="atelier-dash-hero-text">
          <span className="atelier-dash-kicker"><i /> YOUR PERSONAL UNIVERSE</span>
          <p className="atelier-dash-date">{dateLabel}</p>
          <h1>{greeting || 'Good day'},<br /><em>{name}.</em></h1>
          <p className="atelier-dash-tagline">Discipline today. A stronger tomorrow.</p>
          <blockquote>“Small steps in the right direction<br className="dash-desktop-only" /> still take you to amazing places.”</blockquote>
        </div>
      </section>

      <section className="atelier-dash-metrics" aria-label="Your progress">
        <article className="atelier-dash-metric atelier-dash-metric-link" role="button" tabIndex={0} aria-label="Open tasks" onClick={() => navigate('My tasks')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigate('My tasks'); } }}>
          <div className="atelier-dash-metric-icon gold"><Icon name="tasks" /></div>
          <div className="atelier-dash-metric-copy"><span>Tasks</span><strong>{completedTasks}<small> / {tasks.length}</small></strong><p>completed</p></div>
          <div className="atelier-dash-ring" style={{ '--ring-progress': `${safeTaskProgress}%` }}><span /></div>
        </article>
        <article className="atelier-dash-metric atelier-dash-metric-link" role="link" tabIndex={0} aria-label="Open goals" onClick={() => navigate('Goals')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigate('Goals'); } }}>
          <div className="atelier-dash-metric-icon purple"><Icon name="goals" /></div>
          <div className="atelier-dash-metric-copy"><span>Goals</span><strong>{goals.filter((goal) => Number(goal.progress) < 100).length}<small> / {goals.length}</small></strong><p>in progress</p></div>
          <div className="atelier-dash-ring purple-ring" style={{ '--ring-progress': `${goalProgress}%` }}><span /></div>
        </article>
        <article className="atelier-dash-metric atelier-dash-metric-link" role="button" tabIndex={0} aria-label="Open habits" onClick={() => navigate('Habits')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigate('Habits'); } }}>
          <div className="atelier-dash-metric-icon amber"><Icon name="habits" /></div>
          <div className="atelier-dash-metric-copy"><span>Habits</span><strong>{completedHabits}<small> / {habits.length}</small></strong><p>done today</p></div>
          <div className="atelier-dash-ring amber-ring" style={{ '--ring-progress': `${habitProgress}%` }}><span /></div>
        </article>
        <article className="atelier-dash-metric notes-metric atelier-dash-metric-link" role="link" tabIndex={0} aria-label="Open notes" onClick={() => navigate('Notes')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigate('Notes'); } }}>
          <div className="atelier-dash-metric-icon gold"><Icon name="notes" /></div>
          <div className="atelier-dash-metric-copy"><span>Notes</span><strong>{notes.length}</strong><p>saved</p></div>
          <div className="atelier-dash-note-art" aria-hidden="true"><span>〰</span><i>✦</i></div>
        </article>
      </section>

      <section className="atelier-dash-work-grid">
        <article className="atelier-dash-card atelier-dash-tasks">
          <header className="atelier-dash-card-head"><h2><span className="dash-sun">☀</span>Today’s Tasks</h2><button type="button" onClick={() => navigate('My tasks')}>View all <span>→</span></button></header>
          {typeof renderTaskList === 'function' ? renderTaskList({ tasks: tasks.slice(0, 5), compact: true }) : <div className="atelier-dash-empty">Your tasks will appear here.</div>}
          <button className="atelier-dash-add-task" type="button" onClick={() => { setTaskFormOpen(true); navigate('My tasks'); }}><span>＋</span> Add a new task... <b>+</b></button>
        </article>

        <article className="atelier-dash-card atelier-dash-core">
          <header className="atelier-dash-card-head"><h2>Core Stats</h2><button type="button" onClick={() => navigate('My tasks')}>View details <span>→</span></button></header>
          <div className="atelier-dash-core-list">
            <button type="button" className="atelier-dash-core-row atelier-dash-core-link" onClick={() => navigate('My tasks')} aria-label="Open tasks"><span className="core-icon physical"><Icon name="tasks" /></span><div className="core-content"><div><strong>Task completion</strong><b>{safeTaskProgress}%</b></div><div className="atelier-dash-bar"><span style={{ width: `${safeTaskProgress}%` }} /></div></div></button>
            <button type="button" className="atelier-dash-core-row atelier-dash-core-link" onClick={() => navigate('Goals')} aria-label="Open goals"><span className="core-icon mental"><Icon name="goals" /></span><div className="core-content"><div><strong>Goal progress</strong><b>{goalProgress}%</b></div><div className="atelier-dash-bar purple-bar"><span style={{ width: `${goalProgress}%` }} /></div></div></button>
            <button type="button" className="atelier-dash-core-row atelier-dash-core-link" onClick={() => navigate('Habits')} aria-label="Open habits"><span className="core-icon discipline"><Icon name="habits" /></span><div className="core-content"><div><strong>Habit consistency</strong><b>{habitProgress}%</b></div><div className="atelier-dash-bar orange-bar"><span style={{ width: `${habitProgress}%` }} /></div></div></button>
            <button type="button" className="atelier-dash-core-row atelier-dash-core-link" onClick={() => navigate('Notes')} aria-label="Open notes"><span className="core-icon health"><Icon name="notes" /></span><div className="core-content"><div><strong>Notes captured</strong><b>{notes.length}</b></div><div className="atelier-dash-bar green-bar"><span style={{ width: `${Math.min(100, notes.length * 20)}%` }} /></div></div></button>
          </div>
        </article>

        <aside className="atelier-dash-cosmic-card"><div className="atelier-dash-card-planet" aria-hidden="true"><div /></div><div className="atelier-dash-cosmic-copy"><span>✦</span><p>Same universe.<br />A brighter you.</p><div className="atelier-dash-moons">☾ ◐ ◑ ☽</div></div></aside>
      </section>

      <section className="atelier-dash-bottom-grid">
        <article className="atelier-dash-card">
          <header className="atelier-dash-card-head"><h2><span className="dash-sun">✧</span>Today’s Habits</h2><button type="button" onClick={() => navigate('Habits')}>View all <span>→</span></button></header>
          <p className="atelier-dash-subdate">{dateLabel}</p>
          {typeof renderHabitList === 'function' ? renderHabitList({ limit: 4 }) : <div className="atelier-dash-empty">Your habits will appear here.</div>}
        </article>
        <article className="atelier-dash-card">
          <header className="atelier-dash-card-head"><h2><span className="dash-sun">✧</span>Your Goals</h2><button type="button" onClick={() => navigate('Goals')}>View all <span>→</span></button></header>
          {goals.length ? <div className="atelier-dash-goals">{goals.slice(0, 3).map((goal) => <div className="atelier-dash-goal" key={goal.id} role="link" tabIndex={0} aria-label={`Open goal: ${goal.title}`} onClick={() => navigate('Goals')} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); navigate('Goals'); } }}><div><strong>{goal.title}</strong><span>{Number(goal.progress) || 0}%</span></div><p>{goal.detail || 'Keep moving forward.'}</p><div className="atelier-dash-bar"><span style={{ width: `${Math.max(0, Math.min(100, Number(goal.progress) || 0))}%` }} /></div></div>)}</div> : <div className="atelier-dash-empty">Set a goal worth showing up for.</div>}
          <button className="atelier-dash-inline-add" type="button" onClick={() => { setGoalFormOpen(true); navigate('Goals'); }}>＋ Add a goal</button>
        </article>
      </section>
    </main>
  );
}
