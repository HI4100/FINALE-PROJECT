import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import Icon from '../../components/Icon.jsx'
import './Settings.css'

const ACCENTS = [
  { name: 'Electric Amber', color: '#f5a000', soft: '#392b13' },
  { name: 'Cosmic Violet', color: '#b4a0ff', soft: '#27213f' },
  { name: 'Hyper Cobalt', color: '#3b82f6', soft: '#172d50' },
  { name: 'Crimson Blaze', color: '#f43f5e', soft: '#451d2a' },
]

function readSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem('atelier-settings-v1') || '{}')
    return {
      mode: saved.mode === 'light' ? 'light' : 'dark',
      accent: ACCENTS.some((item) => item.name === saved.accent)
        ? saved.accent
        : 'Cosmic Violet',
    }
  } catch {
    return { mode: 'dark', accent: 'Cosmic Violet' }
  }
}

export default function Settings({ profile, setProfile, setToast, signOut }) {
  const [appearance, setAppearance] = useState(readSettings)
  const [displayName, setDisplayName] = useState(profile?.name || '')
  const [username, setUsername] = useState(profile?.username || '')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    setDisplayName(profile?.name || '')
    setUsername(profile?.username || '')
  }, [profile?.name, profile?.username])

  useEffect(() => {
    const root = document.documentElement
    const selected = ACCENTS.find((item) => item.name === appearance.accent) || ACCENTS[1]

    root.dataset.atelierTheme = appearance.mode

const themeVariables = appearance.mode === 'light'
  ? {
      '--bg': '#f4f5f9',
      '--sidebar': '#ffffff',
      '--panel': '#ffffff',
      '--border': '#e1e4ed',
      '--muted': '#687084',
      '--text': '#252a37',
    }
  : {
      '--bg': '#0b0b17',
      '--sidebar': '#101020',
      '--panel': '#151525',
      '--border': '#2a2942',
      '--muted': '#a09db8',
      '--text': '#f1efff',
    }

Object.entries(themeVariables).forEach(([key, value]) => {
  root.style.setProperty(key, value)
})

root.style.setProperty('--accent', selected.color)
root.style.setProperty('--accent-soft', selected.soft)
root.style.setProperty('--settings-accent', selected.color)
root.style.setProperty('--settings-accent-soft', selected.soft)

    try {
      localStorage.setItem('atelier-settings-v1', JSON.stringify(appearance))
    } catch {
      setToast('Could not save appearance preferences on this device.')
    }
  }, [appearance, setToast])

  function changeAppearance(key, value) {
    setAppearance((current) => ({ ...current, [key]: value }))
  }

  async function saveProfile(event) {
    event.preventDefault()

    const cleanName = displayName.trim()
    const cleanUsername = username.trim().replace(/^@/, '').toLowerCase()

    if (!cleanName) {
      setToast('Please enter your display name.')
      return
    }

    if (cleanUsername && !/^[a-z0-9_.]{3,24}$/.test(cleanUsername)) {
      setToast('Username must be 3–24 characters: letters, numbers, underscores or periods.')
      return
    }

    setSaving(true)

    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser()
      if (userError) throw userError
      if (!user) throw new Error('Please sign in again before editing your profile.')

      const { data, error } = await supabase.auth.updateUser({
        data: {
          ...(user.user_metadata || {}),
          name: cleanName,
          username: cleanUsername,
        },
      })

      if (error) throw error

      const nextProfile = {
        ...profile,
        name: data.user?.user_metadata?.name || cleanName,
        username: data.user?.user_metadata?.username || cleanUsername,
        email: data.user?.email || user.email || profile?.email || '',
      }

      setProfile(nextProfile)
      setToast('Profile saved successfully.')
    } catch (error) {
      setToast(error?.message || 'Could not save your profile.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className="settings-page">
      <header className="settings-heading">
        <div className="settings-eyebrow">SYSTEM CONFIGURATION</div>
        <h1>Settings</h1>
        <p>Personalize the look of your space and manage your account.</p>
      </header>

      <div className="settings-grid">
        <section className="settings-card settings-appearance">
          <div className="settings-card-heading">
            <h2>Appearance</h2>
            <p>Saved on this device.</p>
          </div>

          <div className="settings-label">MODE</div>

          <div className="settings-mode-grid">
            <button
              type="button"
              className={`settings-mode-option ${appearance.mode === 'dark' ? 'selected' : ''}`}
              onClick={() => changeAppearance('mode', 'dark')}
              aria-pressed={appearance.mode === 'dark'}
            >
              <span className="settings-preview settings-preview-dark">
                <span className="preview-line preview-line-short" />
                <span className="preview-line preview-line-accent" />
                <span className="preview-line preview-line-medium" />
                {appearance.mode === 'dark' && <span className="preview-check">✓</span>}
              </span>
              <span className="settings-mode-caption">
                <Icon name="moon" />
                Obsidian dark
              </span>
            </button>

            <button
              type="button"
              className={`settings-mode-option ${appearance.mode === 'light' ? 'selected' : ''}`}
              onClick={() => changeAppearance('mode', 'light')}
              aria-pressed={appearance.mode === 'light'}
            >
              <span className="settings-preview settings-preview-light">
                <span className="preview-line preview-line-short" />
                <span className="preview-line preview-line-accent" />
                <span className="preview-line preview-line-medium" />
                {appearance.mode === 'light' && <span className="preview-check">✓</span>}
              </span>
              <span className="settings-mode-caption">
                <span className="settings-sun">☼</span>
                Swiss light
              </span>
            </button>
          </div>

          <div className="settings-label settings-accent-label">ACCENT PALETTE</div>

          <div className="settings-accent-grid">
            {ACCENTS.map((accent) => {
              const selected = appearance.accent === accent.name

              return (
                <button
                  type="button"
                  key={accent.name}
                  className={`settings-accent-option ${selected ? 'selected' : ''}`}
                  onClick={() => changeAppearance('accent', accent.name)}
                  aria-pressed={selected}
                  style={{ '--swatch': accent.color }}
                >
                  <span className="settings-color-dot">
                    {selected && '✓'}
                  </span>
                  <span className="settings-accent-name">{accent.name}</span>
                </button>
              )
            })}
          </div>

          <p className="settings-saved-note">
            <Icon name="check" />
            Your appearance preferences are saved automatically.
          </p>
        </section>

        <div className="settings-right-column">
          <section className="settings-card settings-profile">
            <div className="settings-card-heading">
              <h2>Profile</h2>
              <p>Manage your personal information.</p>
            </div>

            <form className="settings-profile-form" onSubmit={saveProfile}>
              <label htmlFor="settings-display-name">Display name</label>
              <input
                id="settings-display-name"
                type="text"
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                placeholder="Your display name"
                maxLength={80}
                autoComplete="name"
                required
              />

              <label htmlFor="settings-username">Username</label>
              <input
                id="settings-username"
                type="text"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder="your_username"
                maxLength={24}
                autoComplete="username"
              />

              <label htmlFor="settings-email">Email</label>
              <input
                id="settings-email"
                type="email"
                value={profile?.email || ''}
                readOnly
                disabled
              />

              <p className="settings-account-note">
                Signed in via email and password
              </p>

              <button
                className="settings-save-button"
                type="submit"
                disabled={saving}
              >
                {saving ? 'Saving…' : 'Save profile'}
              </button>
            </form>
          </section>

          <section className="settings-card settings-session">
            <div className="settings-card-heading">
              <h2>Session</h2>
              <p>Sign out of atelier. on this device.</p>
            </div>

            <button
              type="button"
              className="settings-signout-button"
              onClick={signOut}
            >
              <span aria-hidden="true">↪</span>
              Sign out
            </button>
          </section>
        </div>
      </div>
    </section>
  )
}
