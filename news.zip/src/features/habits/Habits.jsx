import React, { useMemo, useState } from 'react';
import './Habits.css';
import heroWallpaper from '../../assets/atelier-hero-wallpaper.jpg';

const CATEGORY_META = {
  'Health & Fitness': { key: 'health', icon: 'dumbbell', mark: '✣' },
  'Study & Learning': { key: 'study', icon: 'book-open', mark: '▣' },
  Lifestyle: { key: 'lifestyle', icon: 'leaf', mark: '❧' },
  Mindset: { key: 'mindset', icon: 'brain', mark: '♟' },
  Discipline: { key: 'discipline', icon: 'target', mark: '◎' },
};
const CATEGORY_NAMES = Object.keys(CATEGORY_META);
function localDayKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function habitCategory(habit) {
  const raw = habit?.category || habit?.type || '';
  if (CATEGORY_META[raw]) return raw;
  const text = `${habit?.title || habit?.name || ''} ${habit?.detail || habit?.description || ''}`.toLowerCase();
  if (/workout|fitness|exercise|gym|water|hydration|healthy|health|run|body/.test(text)) return 'Health & Fitness';
  if (/study|read|book|learn|exam|network|course/.test(text)) return 'Study & Learning';
  if (/meditat|namaz|mindful|calm|journal|gratitude|morning planning/.test(text)) return 'Mindset';
  if (/sleep|routine|morning|evening|social media|screen|clean|lifestyle/.test(text)) return 'Lifestyle';
  return 'Discipline';
}
function startOfWeek(date = new Date()) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d;
}
function safeIds(value) { return Array.isArray(value) ? value : []; }

export default function Habits({
  data,
  habitFormOpen = false,
  setHabitFormOpen = () => {},
  habitTitle = '',
  setHabitTitle = () => {},
  habitDetail = '',
  setHabitDetail = () => {},
  addHabit = () => {},
  toggleHabit = () => {},
  deleteHabit = () => {},
  Icon,
}) {
  const [tab, setTab] = useState('Today');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [menuId, setMenuId] = useState(null);
  const habits = Array.isArray(data?.habits) ? data.habits : [];
  const completionMap = data?.completedHabits && typeof data.completedHabits === 'object' ? data.completedHabits : {};
  const today = localDayKey();
  const todayIds = safeIds(completionMap[today]);
  const weekDays = useMemo(() => {
    const start = startOfWeek();
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      const key = localDayKey(date);
      const ids = safeIds(completionMap[key]);
      const done = habits.filter((habit) => ids.includes(habit.id)).length;
      return { key, date, label: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i], done, total: habits.length, percent: habits.length ? Math.round(done / habits.length * 100) : 0, isToday: key === today };
    });
  }, [completionMap, habits, today]);
  const enriched = useMemo(() => habits.map((habit) => ({
    ...habit,
    _title: habit.title || habit.name || 'Untitled habit',
    _detail: habit.detail || habit.description || 'A small step, repeated.',
    _category: habitCategory(habit),
    _done: todayIds.includes(habit.id),
    _weekDone: weekDays.some((day) => safeIds(completionMap[day.key]).includes(habit.id)),
  })), [habits, todayIds, weekDays, completionMap]);
  const visible = enriched.filter((habit) => {
    const matchesCategory = categoryFilter === 'All' || habit._category === categoryFilter;
    const matchesTab = tab !== 'This Week' || habit._weekDone;
    return matchesCategory && matchesTab;
  });
  const doneCount = enriched.filter((habit) => habit._done).length;
  const categories = CATEGORY_NAMES;
  const countCategory = (category) => enriched.filter((habit) => habit._category === category).length;
  const doneCategory = (category) => enriched.filter((habit) => habit._category === category && habit._done).length;
  const completedDays = weekDays.filter((day) => day.done > 0).length;
  const submitHabit = (event) => {
    event.preventDefault();
    if (!habitTitle.trim()) return;
    addHabit(event);
  };

  return (
    <main className="atelier-habits-page">
      <section className="ah-hero" style={{ '--ah-hero-image': `url("${heroWallpaper}")` }}>
        <div className="ah-hero-shade" />
        <div className="ah-hero-copy">
          <span className="ah-kicker"><i /> YOUR PERSONAL UNIVERSE</span>
          <h1>Habits</h1>
          <p>Small habits. A better you.</p>
        </div>
        <blockquote>“Consistency<br /> today, a stronger<br /> you tomorrow.”</blockquote>
      </section>

      <div className="ah-toolbar">
        <div className="ah-tabs" role="tablist" aria-label="Habit view">
          {['Today', 'This Week', 'All Habits'].map((item) => <button type="button" key={item} role="tab" aria-selected={tab === item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item}</button>)}
        </div>
        <div className="ah-filter">
          <label htmlFor="ah-category-filter">Category</label>
          <select id="ah-category-filter" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}>
            <option value="All">All categories</option>{categories.map((category) => <option key={category} value={category}>{category}</option>)}
          </select>
        </div>
        <button className="ah-primary" type="button" onClick={() => setHabitFormOpen(true)}><span>＋</span> Add Habit</button>
      </div>

      {habitFormOpen && <form className="ah-new-form" onSubmit={submitHabit}>
        <div className="ah-form-heading"><div><span>✦</span><div><h2>Create a habit</h2><p>Make consistency part of your story.</p></div></div><button type="button" onClick={() => setHabitFormOpen(false)} aria-label="Close form">×</button></div>
        <label>Habit name<input value={habitTitle} onChange={(event) => setHabitTitle(event.target.value)} placeholder="e.g. Read 20 pages" required maxLength={100} /></label>
        <label>Description<textarea value={habitDetail} onChange={(event) => setHabitDetail(event.target.value)} placeholder="What does this habit look like?" rows={2} maxLength={240} /></label>
        <div className="ah-form-actions"><button className="ah-primary" type="submit">Save habit ↗</button><button className="ah-secondary" type="button" onClick={() => setHabitFormOpen(false)}>Cancel</button></div>
      </form>}

      <div className="ah-main-grid">
        <section className="ah-panel ah-today-panel">
          <header className="ah-panel-heading">
            <h2><span>☀</span>{tab === 'This Week' ? 'This Week’s Habits' : tab === 'All Habits' ? 'All Habits' : 'Today’s Habits'}</h2>
            <div className="ah-completion"><strong>{doneCount}</strong> / {enriched.length} completed <div className="ah-mini-progress"><span style={{ width: `${enriched.length ? doneCount / enriched.length * 100 : 0}%` }} /></div></div>
          </header>
          <div className="ah-habit-list">
            {visible.length ? visible.map((habit) => {
              const category = habit._category;
              const meta = CATEGORY_META[category];
              return <article className={`ah-habit-row ${habit._done ? 'done' : ''}`} key={habit.id}>
                <div className={`ah-habit-icon ${meta.key}`}>{Icon ? <Icon name={meta.icon} /> : <span>{meta.mark}</span>}</div>
                <div className="ah-habit-copy"><h3>{habit._title}</h3><p>{habit._detail}</p><span className={`ah-habit-category ${meta.key}`}>{category}</span></div>
                <button className={`ah-check ${habit._done ? 'checked' : ''}`} type="button" aria-pressed={habit._done} aria-label={`${habit._done ? 'Mark incomplete' : 'Complete'} ${habit._title}`} onClick={() => toggleHabit(habit.id)}>{habit._done ? '✓' : ''}</button>
                <div className="ah-row-menu-wrap"><button className="ah-row-menu" type="button" aria-label={`Actions for ${habit._title}`} aria-expanded={menuId === habit.id} onClick={() => setMenuId(menuId === habit.id ? null : habit.id)}>⋮</button>{menuId === habit.id && <div className="ah-action-menu"><button type="button" onClick={() => { toggleHabit(habit.id); setMenuId(null); }}>{habit._done ? 'Mark incomplete' : 'Mark complete'}</button><button type="button" onClick={() => { deleteHabit(habit.id); setMenuId(null); }}>Delete habit</button></div>}</div>
              </article>;
            }) : <div className="ah-empty"><span>✧</span><h3>{tab === 'This Week' ? 'No habits completed this week yet' : 'No habits in this category'}</h3><p>Add a habit or choose another category.</p></div>}
          </div>
          <button className="ah-add-inline" type="button" onClick={() => setHabitFormOpen(true)}><span>＋</span> Add a new habit...</button>
        </section>

        <aside className="ah-side-column">
          <section className="ah-panel ah-week-panel">
            <header className="ah-panel-heading"><h2><span className="ah-bars">▥</span>Weekly Consistency</h2><span className="ah-week-count">{completedDays} / 7 days</span></header>
            <div className="ah-week-days">{weekDays.map((day) => <button type="button" className={`ah-week-day ${day.isToday ? 'today' : ''}`} key={day.key} title={`${day.label}: ${day.done}/${day.total} habits completed`} onClick={() => setTab('This Week')}><span className="ah-day-ring" style={{ '--ah-day-progress': `${day.percent}%` }}><i /></span><span>{day.label}</span></button>)}</div>
          </section>

          <section className="ah-panel ah-category-panel">
            <header className="ah-panel-heading"><h2><span className="ah-category-spark">✿</span>Habit Categories</h2><button type="button" onClick={() => { setCategoryFilter('All'); setTab('All Habits'); }}>View all <span>→</span></button></header>
            {categories.map((category) => <button type="button" key={category} className={`ah-category-row ${categoryFilter === category ? 'selected' : ''}`} onClick={() => { setCategoryFilter(categoryFilter === category ? 'All' : category); setTab('All Habits'); }}><span className={`ah-category-icon ${CATEGORY_META[category].key}`}>{CATEGORY_META[category].mark}</span><span>{category}</span><strong>{doneCategory(category)} / {countCategory(category)}</strong><span className="ah-chevron">›</span></button>)}
          </section>

          <section className="ah-quote-card" style={{ '--ah-hero-image': `url("${heroWallpaper}")` }}><div><span>✦</span><blockquote>“Habits build the life<br /> you want.”</blockquote><i /></div></section>
        </aside>
      </div>
    </main>
  );
}
