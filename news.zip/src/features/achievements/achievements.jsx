
import { useMemo, useState } from 'react'
import './Achievements.css'

const ACHIEVEMENTS = [
  { title: 'First Step', description: 'Complete your first task', category: 'Special', icon: '👟', metric: 'tasksDone', target: 1 },
  { title: 'Task Collector', description: 'Complete 5 tasks', category: 'Challenges', icon: '✓', metric: 'tasksDone', target: 5 },
  { title: 'Productive Week', description: 'Complete 10 tasks', category: 'Challenges', icon: '⚡', metric: 'tasksDone', target: 10 },
  { title: 'Task Champion', description: 'Complete 25 tasks', category: 'Challenges', icon: '🏆', metric: 'tasksDone', target: 25 },
  { title: 'Focus Legend', description: 'Complete 50 tasks', category: 'Special', icon: '✦', metric: 'tasksDone', target: 50 },

  { title: '7 Day Streak', description: 'Check in for 7 consecutive days', category: 'Streaks', icon: '🔥', metric: 'streakDays', target: 7 },
  { title: '30 Day Streak', description: 'Maintain a 30 day streak', category: 'Streaks', icon: '♨', metric: 'streakDays', target: 30 },
  { title: 'Unstoppable', description: 'Maintain a 100 day streak', category: 'Streaks', icon: '∞', metric: 'streakDays', target: 100 },
  { title: 'Routine Keeper', description: 'Complete 14 habit check-ins', category: 'Streaks', icon: '☀', metric: 'habitCheckins', target: 14 },
  { title: 'Consistency Pro', description: 'Complete 30 habit check-ins', category: 'Streaks', icon: '✧', metric: 'habitCheckins', target: 30 },

  { title: 'Goal Setter', description: 'Create 5 goals', category: 'Goals', icon: '◎', metric: 'goalsCreated', target: 5 },
  { title: 'Dream Builder', description: 'Create your first goal', category: 'Goals', icon: '◇', metric: 'goalsCreated', target: 1 },
  { title: 'Goal Achiever', description: 'Complete 10 goals', category: 'Goals', icon: '🎯', metric: 'goalsCompleted', target: 10 },
  { title: 'Goal Champion', description: 'Complete 5 goals', category: 'Goals', icon: '♛', metric: 'goalsCompleted', target: 5 },
  { title: 'Steady Progress', description: 'Reach 50% on a goal', category: 'Goals', icon: '↗', metric: 'goalsHalfway', target: 1 },

  { title: 'Habit Starter', description: 'Complete your first habit check-in', category: 'Challenges', icon: '✦', metric: 'habitCheckins', target: 1 },
  { title: 'Habit Builder', description: 'Complete 7 habit check-ins', category: 'Challenges', icon: '🌱', metric: 'habitCheckins', target: 7 },
  { title: 'Habit Master', description: 'Maintain a 30 day streak', category: 'Special', icon: '♜', metric: 'streakDays', target: 30 },
  { title: 'Morning Planner', description: 'Create 3 habits', category: 'Challenges', icon: '☼', metric: 'habitsCreated', target: 3 },
  { title: 'Daily Rhythm', description: 'Complete 20 habit check-ins', category: 'Streaks', icon: '◷', metric: 'habitCheckins', target: 20 },

  { title: 'Note Taker', description: 'Save your first note', category: 'Special', icon: '▤', metric: 'notesCreated', target: 1 },
  { title: 'Knowledge Seeker', description: 'Save 10 notes', category: 'Special', icon: '📖', metric: 'notesCreated', target: 10 },
  { title: 'Thought Collector', description: 'Save 5 notes', category: 'Challenges', icon: '✎', metric: 'notesCreated', target: 5 },
  { title: 'Master Planner', description: 'Complete 15 tasks', category: 'Challenges', icon: '▦', metric: 'tasksDone', target: 15 },
  { title: 'Milestone Maker', description: 'Complete 3 goals', category: 'Goals', icon: '🏅', metric: 'goalsCompleted', target: 3 },

  { title: 'Community Hero', description: 'Help 50 community members', category: 'Community', icon: '♧', metric: 'community', target: 50 },
  { title: 'Team Player', description: 'Participate in community activities', category: 'Community', icon: '♙', metric: 'community', target: 1 },
  { title: 'Atelier Elite', description: 'Complete 100 tracked milestones', category: 'Special', icon: '★', metric: 'milestones', target: 100 },
  { title: 'Rising Star', description: 'Complete 10 tracked milestones', category: 'Special', icon: '✧', metric: 'milestones', target: 10 },
  { title: 'All Rounder', description: 'Use tasks, goals, habits and notes', category: 'Special', icon: '✺', metric: 'featuresUsed', target: 4 },
  { title: 'Goal Momentum', description: 'Reach 100% on a goal', category: 'Goals', icon: '🏁', metric: 'goalsCompleted', target: 1 },
  { title: 'A Clear Mind', description: 'Save 3 personal notes', category: 'Challenges', icon: '☾', metric: 'notesCreated', target: 3 },
  { title: 'The Long Game', description: 'Complete 100 tasks', category: 'Streaks', icon: '♛', metric: 'tasksDone', target: 100 },
]

const CATEGORIES = ['All', 'Challenges', 'Streaks', 'Goals', 'Community', 'Special']

function getLocalDateKey(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function calculateStreak(completedHabits = {}) {
  const activeDates = new Set(
    Object.entries(completedHabits)
      .filter(([, ids]) => Array.isArray(ids) && ids.length > 0)
      .map(([date]) => date),
  )

  const cursor = new Date()
  if (!activeDates.has(getLocalDateKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1)
  }

  let streak = 0

  while (activeDates.has(getLocalDateKey(cursor))) {
    streak += 1
    cursor.setDate(cursor.getDate() - 1)
  }

  return streak
}

function getMetrics(data) {
  const tasksDone = data.tasks.filter((task) => task.done).length
  const goalsCompleted = data.goals.filter((goal) => goal.progress >= 100).length
  const goalsHalfway = data.goals.some((goal) => goal.progress >= 50) ? 1 : 0
  const habitCheckins = Object.values(data.completedHabits || {}).reduce(
    (total, ids) => total + (Array.isArray(ids) ? ids.length : 0),
    0,
  )

  const featuresUsed = [
    data.tasks.length > 0,
    data.goals.length > 0,
    data.habits.length > 0,
    data.notes.length > 0,
  ].filter(Boolean).length

  return {
    tasksDone,
    goalsCreated: data.goals.length,
    goalsCompleted,
    goalsHalfway,
    habitCheckins,
    habitsCreated: data.habits.length,
    notesCreated: data.notes.length,
    streakDays: calculateStreak(data.completedHabits),
    community: 0,
    milestones: tasksDone + goalsCompleted + habitCheckins + data.notes.length,
    featuresUsed,
  }
}

function AchievementCard({ achievement, progress, status }) {
  const percent = Math.min(100, Math.round((progress / achievement.target) * 100))
  const earned = status === 'earned'

  return (
    <article className={`achievement-card achievement-${status}`}>
      <div className="achievement-emblem" aria-hidden="true">
        <span>{achievement.icon}</span>
      </div>

      <h3>{achievement.title}</h3>
      <p>{achievement.description}</p>

      {earned ? (
        <span className="achievement-earned-date">✦ Unlocked</span>
      ) : (
        <>
          <div
            className="achievement-progress-track"
            role="progressbar"
            aria-label={`${achievement.title} progress`}
            aria-valuemin={0}
            aria-valuemax={achievement.target}
            aria-valuenow={Math.min(progress, achievement.target)}
          >
            <span style={{ width: `${percent}%` }} />
          </div>
          <div className="achievement-progress-label">
            {Math.min(progress, achievement.target)} / {achievement.target}
          </div>
        </>
      )}

      <span className="achievement-category">{achievement.category}</span>
    </article>
  )
}

export default function Achievements({ data }) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [section, setSection] = useState('All')

  const metrics = useMemo(() => getMetrics(data), [data])

  const achievements = useMemo(
    () => ACHIEVEMENTS.map((achievement) => {
      const progress = metrics[achievement.metric] || 0
      const status = progress >= achievement.target
        ? 'earned'
        : progress > 0
          ? 'progress'
          : 'locked'

      return { ...achievement, progress, status }
    }),
    [metrics],
  )

  const earnedCount = achievements.filter((item) => item.status === 'earned').length
  const progressCount = achievements.filter((item) => item.status === 'progress').length
  const lockedCount = achievements.filter((item) => item.status === 'locked').length
  const streak = metrics.streakDays
  const specialCount = achievements.filter(
    (item) => item.category === 'Special' && item.status === 'earned',
  ).length

  const visibleAchievements = achievements.filter((item) => {
    const matchesCategory = category === 'All' || item.category === category
    const matchesSearch = `${item.title} ${item.description} ${item.category}`
      .toLowerCase()
      .includes(search.trim().toLowerCase())

    return matchesCategory && matchesSearch
  })

  const sections = section === 'All'
    ? [
        { key: 'earned', title: 'Earned', items: visibleAchievements.filter((item) => item.status === 'earned') },
        { key: 'progress', title: 'In Progress', items: visibleAchievements.filter((item) => item.status === 'progress') },
        { key: 'locked', title: 'Locked', items: visibleAchievements.filter((item) => item.status === 'locked') },
      ]
    : [
        {
          key: section,
          title: section === 'earned' ? 'Earned' : section === 'progress' ? 'In Progress' : 'Locked',
          items: visibleAchievements.filter((item) => item.status === section),
        },
      ]

  return (
    <section className="achievements-page">
      <header className="achievements-toolbar">
        <label className="achievement-search">
          <span aria-hidden="true">⌕</span>
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search achievements..."
            aria-label="Search achievements"
          />
          <kbd>Ctrl K</kbd>
        </label>
        <span className="achievement-total">{ACHIEVEMENTS.length} badges to discover</span>
      </header>

      <header className="achievements-hero">
        <div className="achievement-eyebrow">YOUR JOURNEY, RECOGNIZED</div>
        <h1>Achievements</h1>
        <p>Badges for your journey. Small wins. Bigger you.</p>
      </header>

      <section className="achievement-summary" aria-label="Achievement statistics">
        <div className="achievement-summary-main">
          <div className="achievement-trophy">♛</div>
          <div className="achievement-summary-copy">
            <span className="achievement-eyebrow">ACHIEVEMENTS UNLOCKED</span>
            <strong>{earnedCount} <span>/ {ACHIEVEMENTS.length}</span></strong>
            <div className="achievement-summary-track">
              <span style={{ width: `${earnedCount / ACHIEVEMENTS.length * 100}%` }} />
            </div>
            <small>{Math.round(earnedCount / ACHIEVEMENTS.length * 100)}% complete</small>
          </div>
        </div>

        <div className="achievement-stat">
          <span>🔥</span>
          <div><strong>{streak}</strong><small>Day streak</small></div>
        </div>

        <div className="achievement-stat">
          <span>⚑</span>
          <div><strong>{progressCount}</strong><small>In progress</small></div>
        </div>

        <div className="achievement-stat">
          <span>♛</span>
          <div><strong>{specialCount}</strong><small>Special badges</small></div>
        </div>
      </section>

      <div className="achievement-filter-row">
        <div className="achievement-category-tabs" aria-label="Achievement categories">
          {CATEGORIES.map((item) => (
            <button
              type="button"
              key={item}
              className={category === item ? 'active' : ''}
              onClick={() => setCategory(item)}
              aria-pressed={category === item}
            >
              {item}
            </button>
          ))}
        </div>

        <label className="achievement-status-select">
          <span className="sr-only">Filter by status</span>
          <select value={section} onChange={(event) => setSection(event.target.value)}>
            <option value="All">All statuses</option>
            <option value="earned">Earned</option>
            <option value="progress">In progress</option>
            <option value="locked">Locked</option>
          </select>
        </label>
      </div>

      <div className="achievement-results-summary">
        <span>{earnedCount} earned</span>
        <span>{progressCount} in progress</span>
        <span>{lockedCount} locked</span>
      </div>

      {sections.map((group) => (
        <section className="achievement-section" key={group.key}>
          <div className="achievement-section-heading">
            <h2>
              <span>{group.key === 'earned' ? '🏆' : group.key === 'progress' ? '◉' : '🔒'}</span>
              {group.title}
              <small>{group.items.length}</small>
            </h2>
          </div>

          {group.items.length ? (
            <div className="achievement-card-grid">
              {group.items.map((item) => (
                <AchievementCard
                  key={item.title}
                  achievement={item}
                  progress={item.progress}
                  status={item.status}
                />
              ))}
            </div>
          ) : (
            <div className="achievement-empty">
              No achievements match these filters yet.
            </div>
          )}
        </section>
      ))}
    </section>
  )
}
