import React, { useMemo, useState } from 'react';
import './Tasks.css';

const CATEGORIES = [
  { name: 'Study', color: 'study' },
  { name: 'Workout', color: 'workout' },
  { name: 'Personal', color: 'personal' },
  { name: 'Health', color: 'health' },
  { name: 'Other', color: 'other' },
];

function taskCategory(task) {
  const raw = String(task?.category || 'Other');
  if (/study|work|personal|health|other/i.test(raw)) {
    if (/study/i.test(raw)) return 'Study';
    if (/workout|exercise|fitness/i.test(raw)) return 'Workout';
    if (/personal|planning/i.test(raw)) return 'Personal';
    if (/health/i.test(raw)) return 'Health';
    return 'Other';
  }
  return 'Other';
}

export default function Tasks({ data, completedTasks = 0, search = '', setSearch, taskFormOpen, setTaskFormOpen, renderAddTaskForm, renderTaskList, filteredTasks, Icon }) {
  const [tab, setTab] = useState('Today');
  const [category, setCategory] = useState('All');
  const [monthOffset, setMonthOffset] = useState(0);
  const [selectedDate, setSelectedDate] = useState(new Date().getDate());
  const tasks = Array.isArray(data?.tasks) ? data.tasks : [];
  const completed = tasks.filter(task => task.done);
  const open = tasks.filter(task => !task.done);
  const source = Array.isArray(filteredTasks) ? filteredTasks : tasks;
  const visibleTasks = useMemo(() => source.filter(task => {
    if (tab === 'Completed' && !task.done) return false;
    if (tab === 'Upcoming' && task.done) return false;
    if (tab === 'Today' && task.done) return false;
    if (category !== 'All' && taskCategory(task) !== category) return false;
    return true;
  }), [source, tab, category]);
  const total = tasks.length;
  const doneCount = tasks.filter(task => task.done).length;
  const progress = total ? Math.round(doneCount / total * 100) : 0;
  const monthDate = new Date(new Date().getFullYear(), new Date().getMonth() + monthOffset, 1);
  const monthLabel = monthDate.toLocaleDateString('en', { month: 'short', year: 'numeric' });
  const monthDays = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate();
  const firstDay = (monthDate.getDay() + 6) % 7;
  const today = new Date();
  const monthTasks = tasks.filter(task => task.date && String(task.date).includes(`${monthDate.getFullYear()}-${String(monthDate.getMonth()+1).padStart(2,'0')}`));
  const categoryCounts = CATEGORIES.map(item => ({ ...item, count: tasks.filter(task => taskCategory(task) === item.name).length }));
  const activateAdd = () => setTaskFormOpen(true);

  return (
    <main className="atelier-tasks-page">
      <section className="atelier-tasks-hero">
        <div className="atelier-tasks-hero-shade" />
        <div className="atelier-tasks-hero-copy">
          <span className="atelier-tasks-eyebrow"><i /> YOUR PERSONAL UNIVERSE</span>
          <h1>Tasks</h1>
          <p>Get things done, one step at a time.</p>
        </div>
        <blockquote>“Discipline today,<br />a stronger you<br />tomorrow.”</blockquote>
      </section>

      <div className="atelier-task-toolbar">
        <div className="atelier-task-tabs" role="tablist" aria-label="Task status">
          {['Today', 'Upcoming', 'Completed'].map(item => <button type="button" role="tab" aria-selected={tab === item} className={tab === item ? 'active' : ''} key={item} onClick={() => setTab(item)}>{item}</button>)}
        </div>
        <label className="atelier-task-search"><span className="sr-only">Search tasks</span><input value={search} onChange={e => setSearch?.(e.target.value)} placeholder="Search tasks..." /><span>⌕</span></label>
        <div className="atelier-task-categories" aria-label="Filter by category">
          <button className={category === 'All' ? 'selected' : ''} type="button" onClick={() => setCategory('All')}>All⌄</button>
          {CATEGORIES.map(item => <button type="button" key={item.name} className={category === item.name ? 'selected' : ''} onClick={() => setCategory(category === item.name ? 'All' : item.name)}><i className={item.color} />{item.name}</button>)}
        </div>
        <button className="atelier-task-add-button" type="button" onClick={activateAdd}><span>＋</span> Add Task</button>
      </div>

      {taskFormOpen && <section className="atelier-task-form-panel"><div className="atelier-task-form-title"><h2>New task</h2><button type="button" onClick={() => setTaskFormOpen(false)} aria-label="Close task form">×</button></div>{typeof renderAddTaskForm === 'function' ? renderAddTaskForm() : <p>Task form unavailable.</p>}</section>}

      <div className="atelier-task-main-grid">
        <section className="atelier-task-panel atelier-task-list-panel">
          <header className="atelier-task-panel-head"><h2><span className="atelier-sun-icon">☀</span>{tab === 'Today' ? "Today's Tasks" : `${tab} Tasks`}</h2><div className="atelier-task-panel-progress"><strong>{doneCount}</strong> / {total} completed <span className="atelier-task-progress-track"><i style={{ width: `${progress}%` }} /></span></div></header>
          {visibleTasks.length ? (typeof renderTaskList === 'function' ? renderTaskList({ tasks: visibleTasks, compact: false }) : <p className="atelier-task-empty">Your tasks will appear here.</p>) : <div className="atelier-task-empty"><span>✦</span><strong>No tasks in this view</strong><p>Add a task or change your filters to see it here.</p></div>}
          <button className="atelier-task-add-row" type="button" onClick={activateAdd}><span>＋</span> Add a new task... <b>＋</b></button>
        </section>

        <aside className="atelier-task-side-column">
          <section className="atelier-task-panel atelier-task-overview">
            <header className="atelier-task-panel-head"><h2><span className="atelier-bars-icon">▥</span>Task Overview</h2><span className="atelier-task-period">Today⌄</span></header>
            <div className="atelier-task-overview-body"><div className="atelier-task-donut" style={{ '--task-percent': `${progress}%` }}><div><strong>{progress}%</strong></div></div><div className="atelier-task-overview-total"><strong>{doneCount} <small>/ {total}</small></strong><span>completed</span></div><div className="atelier-task-category-counts">{categoryCounts.map(item => <div key={item.name}><i className={item.color} /><span>{item.name}</span><b>{item.count}</b></div>)}</div></div>
          </section>
          <section className="atelier-task-panel atelier-task-calendar">
            <header className="atelier-task-panel-head"><h2><span className="atelier-calendar-icon">▦</span>Calendar</h2><div className="atelier-calendar-controls"><button type="button" onClick={() => setMonthOffset(v => v - 1)} aria-label="Previous month">‹</button><span>{monthLabel}</span><button type="button" onClick={() => setMonthOffset(v => v + 1)} aria-label="Next month">›</button></div></header>
            <div className="atelier-calendar-grid"><div className="atelier-calendar-weekdays">{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(day => <span key={day}>{day}</span>)}</div><div className="atelier-calendar-days">{Array.from({length:firstDay},(_,i)=><span key={`blank-${i}`} />)}{Array.from({length:monthDays},(_,i)=>{const day=i+1;const isToday=monthOffset===0&&day===today.getDate();const hasTask=day===today.getDate()||monthTasks.some(t=>Number(String(t.date).slice(-2))===day);return <button key={day} type="button" className={`${selectedDate===day?'selected':''} ${isToday?'today':''}`} onClick={()=>setSelectedDate(day)}>{day}{hasTask&&<i/>}</button>})}</div></div>
          </section>
        </aside>
      </div>

      <div className="atelier-task-bottom-grid">
        <section className="atelier-task-panel"><header className="atelier-task-panel-head"><h2><span className="atelier-clock-icon">◷</span>Upcoming Tasks</h2><button type="button" className="atelier-task-view-all" onClick={() => setTab('Upcoming')}>View all <span>→</span></button></header>{open.slice(0,3).length ? renderTaskList?.({ tasks: open.slice(0,3), compact: false }) : <p className="atelier-task-empty">No upcoming tasks yet.</p>}</section>
        <section className="atelier-task-panel"><header className="atelier-task-panel-head"><h2><span className="atelier-check-icon">✓</span>Completed Tasks</h2><button type="button" className="atelier-task-view-all" onClick={() => setTab('Completed')}>View all <span>→</span></button></header>{completed.slice(0,3).length ? renderTaskList?.({ tasks: completed.slice(0,3), compact: false }) : <p className="atelier-task-empty">Completed tasks will appear here.</p>}</section>
      </div>
    </main>
  );
}
