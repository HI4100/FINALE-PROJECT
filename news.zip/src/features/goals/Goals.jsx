import React, { useMemo, useState } from 'react';
import './Goals.css';
import heroWallpaper from '../../assets/atelier-hero-wallpaper.jpg';

const CATEGORY_STYLES = {
  Personal: 'personal',
  Career: 'career',
  Fitness: 'fitness',
  Learning: 'learning',
  Finance: 'finance',
  Other: 'other',
};

function getCategory(goal) {
  const raw = goal?.category || goal?.type || '';
  if (raw && CATEGORY_STYLES[raw]) return raw;
  const text = `${goal?.title || ''} ${goal?.detail || ''}`.toLowerCase();
  if (/run|fitness|workout|health|marathon|exercise/.test(text)) return 'Fitness';
  if (/learn|study|book|exam|course|skill|read/.test(text)) return 'Learning';
  if (/career|job|brand|work|business|project/.test(text)) return 'Career';
  if (/save|money|finance|budget/.test(text)) return 'Finance';
  return 'Personal';
}

export default function Goals({
  data, goalFormOpen, setGoalFormOpen, goalTitle, setGoalTitle,
  goalDetail, setGoalDetail, addGoal, deleteGoal, adjustGoal, Icon,
}) {
  const [tab, setTab] = useState('Active');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [menuId, setMenuId] = useState(null);
  const goals = Array.isArray(data?.goals) ? data.goals : [];
  const categorized = useMemo(() => goals.map((goal) => ({ ...goal, _category: getCategory(goal), _progress: Math.max(0, Math.min(100, Number(goal.progress) || 0)) })), [goals]);
  const visibleGoals = categorized.filter((goal) => {
    const statusMatches = tab === 'All' || (tab === 'Achieved' ? goal._progress >= 100 : goal._progress < 100);
    return statusMatches && (categoryFilter === 'All' || goal._category === categoryFilter);
  });
  const overall = goals.length ? Math.round(goals.reduce((sum, goal) => sum + Math.max(0, Math.min(100, Number(goal.progress) || 0)), 0) / goals.length) : 0;
  const achieved = goals.filter((goal) => (Number(goal.progress) || 0) >= 100).length;
  const categories = ['Personal', 'Career', 'Fitness', 'Learning', 'Finance', 'Other'];
  const countFor = (category) => categorized.filter((goal) => goal._category === category).length;

  return (
    <main className="atelier-goals-page">
      <section className="ag-hero" style={{ '--ag-hero-image': `url("${heroWallpaper}")` }}>
        <div className="ag-hero-shade" />
        <div className="ag-hero-copy">
          <span className="ag-kicker"><i /> YOUR PERSONAL UNIVERSE</span>
          <h1>Goals</h1>
          <p>Clear goals. A better you.</p>
        </div>
        <blockquote>“Goals turn<br /> intention into<br /> reality.”</blockquote>
      </section>

      <div className="ag-toolbar">
        <div className="ag-tabs" role="tablist" aria-label="Goal status">
          {['Active', 'Achieved', 'All'].map((item) => (
            <button key={item} type="button" role="tab" aria-selected={tab === item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item}</button>
          ))}
        </div>
        <div className="ag-filter-wrap">
          <label className="ag-filter-label" htmlFor="ag-category-filter">Category</label>
          <select id="ag-category-filter" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
            <option>All</option>{categories.map((category) => <option key={category}>{category}</option>)}
          </select>
        </div>
        <button className="ag-primary-button" type="button" onClick={() => setGoalFormOpen(true)}><span>＋</span> New Goal</button>
      </div>

      {goalFormOpen && (
        <form className="ag-new-goal" onSubmit={addGoal}>
          <div className="ag-form-heading"><div><span className="ag-form-spark">✦</span><div><h2>Create a goal</h2><p>Give your next chapter a direction.</p></div></div><button type="button" aria-label="Close goal form" onClick={() => setGoalFormOpen(false)}>×</button></div>
          <label>Goal title<input value={goalTitle} onChange={(e) => setGoalTitle(e.target.value)} placeholder="e.g. Read 12 books this year" maxLength={120} required autoFocus /></label>
          <label>Why it matters<textarea value={goalDetail} onChange={(e) => setGoalDetail(e.target.value)} placeholder="Describe what achieving this goal means to you…" rows={2} maxLength={300} /></label>
          <div className="ag-form-actions"><button className="ag-primary-button" type="submit">Save goal ↗</button><button className="ag-secondary-button" type="button" onClick={() => setGoalFormOpen(false)}>Cancel</button></div>
        </form>
      )}

      <div className="ag-main-grid">
        <section className="ag-goal-list" aria-label="Goals">
          {visibleGoals.length ? visibleGoals.map((goal) => {
            const category = goal._category;
            const iconName = category === 'Learning' ? 'book-open' : category === 'Career' ? 'laptop' : category === 'Fitness' ? 'dumbbell' : category === 'Finance' ? 'wallet' : 'sparkles';
            return (
              <article className={`ag-goal-card ${goal._progress >= 100 ? 'is-achieved' : ''}`} key={goal.id}>
                <div className={`ag-goal-icon ${CATEGORY_STYLES[category]}`}>{Icon ? <Icon name={iconName} /> : <span>✦</span>}</div>
                <div className="ag-goal-content">
                  <button className={`ag-category-pill ${CATEGORY_STYLES[category]}`} type="button" onClick={() => setCategoryFilter(category)} title={`Filter ${category} goals`}>{category}</button>
                  <h2>{goal.title}</h2>
                  <p>{goal.detail || 'Keep moving forward, one step at a time.'}</p>
                  <div className="ag-progress-line"><span className={CATEGORY_STYLES[category]} style={{ width: `${goal._progress}%` }} /></div>
                  <div className="ag-progress-meta"><span>{goal._progress >= 100 ? 'Achieved' : 'Progress'}</span><strong>{goal._progress}%</strong></div>
                </div>
                <div className="ag-goal-actions">
                  <span className="ag-due-label"><span>◷</span><span>Target<br /><b>{goal.target || 'Ongoing'}</b></span></span>
                  <button className="ag-menu-button" type="button" aria-label={`Goal actions for ${goal.title}`} aria-expanded={menuId === goal.id} onClick={() => setMenuId(menuId === goal.id ? null : goal.id)}>⋮</button>
                  {menuId === goal.id && <div className="ag-action-menu">
                    <button type="button" onClick={() => { adjustGoal(goal.id, 10); setMenuId(null); }}>＋ Increase progress 10%</button>
                    <button type="button" onClick={() => { adjustGoal(goal.id, -10); setMenuId(null); }}>− Decrease progress 10%</button>
                    <button type="button" onClick={() => { deleteGoal(goal.id); setMenuId(null); }}>Delete goal</button>
                  </div>}
                </div>
              </article>
            );
          }) : <div className="ag-empty"><span>✧</span><h2>No goals here yet</h2><p>{tab === 'Achieved' ? 'Your completed goals will shine here.' : 'Create a goal and start making progress.'}</p><button className="ag-primary-button" type="button" onClick={() => setGoalFormOpen(true)}>＋ Create a goal</button></div>}
        </section>

        <aside className="ag-sidebar">
          <section className="ag-side-card ag-overall-card">
            <h2>Overall Progress</h2>
            <div className="ag-progress-ring" style={{ '--ag-progress': `${overall}%` }}><div><strong>{overall}%</strong><span>{achieved} / {goals.length} goals</span></div></div>
            <p className="ag-overall-caption">Every small step counts.</p>
          </section>
          <section className="ag-side-card ag-categories-card">
            <h2>Goal Categories</h2>
            {categories.map((category) => (
              <button type="button" key={category} className={`ag-category-row ${categoryFilter === category ? 'selected' : ''}`} onClick={() => setCategoryFilter(categoryFilter === category ? 'All' : category)}>
                <span className={`ag-category-mini ${CATEGORY_STYLES[category]}`}>{category === 'Personal' ? '▤' : category === 'Career' ? '▰' : category === 'Fitness' ? '✣' : category === 'Learning' ? '◉' : category === 'Finance' ? '$' : '✦'}</span>
                <span>{category}</span><strong>{countFor(category)}</strong><span className="ag-chevron">›</span>
              </button>
            ))}
            <button type="button" className="ag-reset-filter" onClick={() => setCategoryFilter('All')}>Show all categories ↗</button>
          </section>
        </aside>
      </div>
    </main>
  );
}
