
import roadmapBase from './assets/roadmap-base.webp'
import roadmapMomentum from './assets/roadmap-momentum.webp'
import roadmapProgress from './assets/roadmap-progress.webp'
import roadmapStronger from './assets/roadmap-stronger.webp'
import AnalysisDashboard from './AnalysisDashboard.jsx';
import React, { useEffect, useMemo, useState } from 'react'
import { supabase } from './supabase.js'
import Icon from './components/Icon.jsx'
import CosmicGalaxy from './components/CosmicGalaxy.jsx'
import Overview from './features/overview/Overview.jsx'
import Tasks from './features/tasks/Tasks.jsx'
import Goals from './features/goals/Goals.jsx'
import Habits from './features/habits/Habits.jsx'
import Notes from './features/notes/Notes.jsx'
import { todayKey, loadData, makeId, formatDate } from './utils/workspaceData.js'
import './App.css'

/**
 * Main application coordinator.
 * Owns shared workspace state and passes data/actions to feature screens.
 * Authentication and onboarding flow also live here in this version.
 */
function App() {
  // Shared workspace state: every feature reads from the same source of truth.
  const [data, setData] = useState(loadData)
  const [page, setPage] = useState('Overview')
  const [taskFormOpen, setTaskFormOpen] = useState(false)
  const [goalFormOpen, setGoalFormOpen] = useState(false)
  const [habitFormOpen, setHabitFormOpen] = useState(false)
  const [noteFormOpen, setNoteFormOpen] = useState(false)
  const [taskTitle, setTaskTitle] = useState('')
  const [taskTime, setTaskTime] = useState('')
  const [taskCategory, setTaskCategory] = useState('Personal')
  const [goalTitle, setGoalTitle] = useState('')
  const [goalDetail, setGoalDetail] = useState('')
  const [habitTitle, setHabitTitle] = useState('')
  const [habitDetail, setHabitDetail] = useState('')
  const [noteTitle, setNoteTitle] = useState('')
  const [noteBody, setNoteBody] = useState('')
  const [editingNoteId, setEditingNoteId] = useState(null)
  const [search, setSearch] = useState('')
  const [toast, setToast] = useState('')
  const [resetDialogOpen, setResetDialogOpen] = useState(false)
  const [buildingProgress, setBuildingProgress] = useState(0)
  const [flow, setFlow] = useState(() => localStorage.getItem('atelier-flow-v1') || 'welcome')
  const [setupStep, setSetupStep] = useState(0)
  const [authMode, setAuthMode] = useState('signup')
  const [profile, setProfile] = useState(() => {
    try { return JSON.parse(localStorage.getItem('atelier-profile-v1') || '{}') } catch { return {} }
  })
  const [setup, setSetup] = useState(() => {
    try { return JSON.parse(localStorage.getItem('atelier-setup-v1') || '{}') } catch { return {} }
  })
  const [authName, setAuthName] = useState('')
  const [authUsername, setAuthUsername] = useState('')
  const [authEmail, setAuthEmail] = useState('')
  const [authPassword, setAuthPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [recoveryMode, setRecoveryMode] = useState(false)
  const [authError, setAuthError] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const passwordStrength = authPassword.length === 0 ? 0 : Math.min(4, (authPassword.length >= 8 ? 1 : 0) + (/[A-Z]/.test(authPassword) && /[a-z]/.test(authPassword) ? 1 : 0) + (/\d/.test(authPassword) ? 1 : 0) + (/[^A-Za-z0-9]/.test(authPassword) ? 1 : 0))

  useEffect(() => {
    try {
      localStorage.setItem('atelier-workspace-v1', JSON.stringify(data))
    } catch {
      setToast('Could not save locally. Check your browser storage settings.')
    }
  }, [data])

  useEffect(() => { localStorage.setItem('atelier-flow-v1', flow) }, [flow])
  useEffect(() => {
    let alive = true
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (!alive) return
      if (error) setAuthError(error.message)
      if (session?.user) {
        const nextProfile = { name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'there', email: session.user.email }
        setProfile(nextProfile)
        setFlow('dashboard')
      } else {
        setFlow((current) => current === 'dashboard' ? 'welcome' : current)
      }
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return
      if (event === 'PASSWORD_RECOVERY') {
        setRecoveryMode(true)
        setAuthMode('login')
        setAuthError('Choose a new password for your Atelier account.')
        setFlow('auth')
      }
      if (session?.user) {
        setProfile({ name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'there', email: session.user.email })
      }
    })
    return () => { alive = false; subscription.unsubscribe() }
  }, [])
  useEffect(() => {
    if (flow !== 'building') return undefined
    const timer = setTimeout(() => setFlow('analysis'), 11000)
    return () => clearTimeout(timer)
  }, [flow])
  useEffect(() => { localStorage.setItem('atelier-setup-v1', JSON.stringify(setup)) }, [setup])
  useEffect(() => { localStorage.setItem('atelier-profile-v1', JSON.stringify(profile)) }, [profile])

  useEffect(() => {
    if (!toast) return undefined
    const timer = setTimeout(() => setToast(''), 3000)
    return () => clearTimeout(timer)
  }, [toast])
  useEffect(() => {
  if (flow !== 'building') {
    setBuildingProgress(0);
    return;
  }

  setBuildingProgress(0);

  const startTime = Date.now();
  const duration = 11000;

  const timer = setInterval(() => {
    const elapsed = Date.now() - startTime;
    const progress = Math.min(100, Math.round((elapsed / duration) * 100));

    setBuildingProgress(progress);
  }, 100);

  return () => clearInterval(timer);
}, [flow]);

  // Derived values used by Overview and the navigation badge.
  const today = todayKey()
  const completedTasks = data.tasks.filter((task) => task.done).length
  const openTasks = data.tasks.length - completedTasks
  const todayHabits = data.completedHabits[today] || []
  const completedHabits = data.habits.filter((habit) => todayHabits.includes(habit.id)).length
  const taskProgress = data.tasks.length ? Math.round((completedTasks / data.tasks.length) * 100) : 0

  const navItems = [
    { label: 'Overview', icon: 'overview' },
    { label: 'My tasks', icon: 'tasks', count: openTasks },
    { label: 'Goals', icon: 'goals' },
    { label: 'Habits', icon: 'habits' },
    { label: 'Notes', icon: 'notes' },
  ]

  const filteredTasks = useMemo(() => {
    const query = search.trim().toLowerCase()
    return data.tasks.filter((task) =>
      `${task.title} ${task.category}`.toLowerCase().includes(query),
    )
  }, [data.tasks, search])

  // Shared data-update helper used by each workspace feature.
  function updateData(key, value) {
    setData((current) => ({ ...current, [key]: value }))
  }

  function addTask(event) {
    event.preventDefault()
    if (!taskTitle.trim()) return
    updateData('tasks', [
      ...data.tasks,
      {
        id: makeId(),
        title: taskTitle.trim(),
        time: taskTime || 'Anytime',
        category: taskCategory,
        done: false,
      },
    ])
    setTaskTitle('')
    setTaskTime('')
    setTaskCategory('Personal')
    setTaskFormOpen(false)
    setToast('Task added to your list.')
  }

  function toggleTask(id) {
    updateData('tasks', data.tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done } : task,
    ))
  }

  function deleteTask(id) {
    updateData('tasks', data.tasks.filter((task) => task.id !== id))
    setToast('Task removed.')
  }

  function addGoal(event) {
    event.preventDefault()
    if (!goalTitle.trim()) return
    updateData('goals', [
      ...data.goals,
      { id: makeId(), title: goalTitle.trim(), detail: goalDetail.trim() || 'A goal worth making time for.', progress: 0, target: 'Ongoing' },
    ])
    setGoalTitle('')
    setGoalDetail('')
    setGoalFormOpen(false)
    setToast('Goal created.')
  }

  function adjustGoal(id, amount) {
    updateData('goals', data.goals.map((goal) =>
      goal.id === id ? { ...goal, progress: Math.max(0, Math.min(100, goal.progress + amount)) } : goal,
    ))
  }

  function deleteGoal(id) {
    updateData('goals', data.goals.filter((goal) => goal.id !== id))
    setToast('Goal removed.')
  }

  function addHabit(event) {
    event?.preventDefault?.()
    const title = habitTitle.trim()
    if (!title) {
      setToast('Enter a habit name first.')
      return
    }
    const nextHabit = {
      id: makeId(),
      title,
      detail: habitDetail.trim() || 'A small step, repeated.',
      icon: '✦',
      category: 'Discipline',
      createdAt: new Date().toISOString(),
    }
    updateData('habits', [...(Array.isArray(data.habits) ? data.habits : []), nextHabit])
    setHabitTitle('')
    setHabitDetail('')
    setHabitFormOpen(false)
    setToast('Habit added.')
  }

  function toggleHabit(id) {
    const todayKeyValue = todayKey()
    const allCompleted = data.completedHabits && typeof data.completedHabits === 'object'
      ? data.completedHabits
      : {}
    const current = Array.isArray(allCompleted[todayKeyValue]) ? allCompleted[todayKeyValue] : []
    const next = current.includes(id)
      ? current.filter((item) => item !== id)
      : [...current, id]
    updateData('completedHabits', { ...allCompleted, [todayKeyValue]: next })
  }

  function deleteHabit(id) {
    updateData('habits', (Array.isArray(data.habits) ? data.habits : []).filter((habit) => habit.id !== id))
    const allCompleted = data.completedHabits && typeof data.completedHabits === 'object'
      ? data.completedHabits
      : {}
    const cleaned = Object.fromEntries(
      Object.entries(allCompleted).map(([day, ids]) => [day, Array.isArray(ids) ? ids.filter((item) => item !== id) : []]),
    )
    updateData('completedHabits', cleaned)
    setToast('Habit removed.')
  }

  function saveNote(event) {
    event.preventDefault()
    if (!noteTitle.trim() || !noteBody.trim()) return
    if (editingNoteId) {
      updateData('notes', data.notes.map((note) =>
        note.id === editingNoteId
          ? { ...note, title: noteTitle.trim(), body: noteBody.trim(), updated: today }
          : note,
      ))
      setToast('Note updated.')
    } else {
      updateData('notes', [
        { id: makeId(), title: noteTitle.trim(), body: noteBody.trim(), updated: today },
        ...data.notes,
      ])
      setToast('Note saved.')
    }
    setNoteTitle('')
    setNoteBody('')
    setEditingNoteId(null)
    setNoteFormOpen(false)
  }

  function editNote(note) {
    setEditingNoteId(note.id)
    setNoteTitle(note.title)
    setNoteBody(note.body)
    setNoteFormOpen(true)
  }

  function deleteNote(id) {
    updateData('notes', data.notes.filter((note) => note.id !== id))
    if (editingNoteId === id) resetNoteForm()
    setToast('Note deleted.')
  }

  function resetNoteForm() {
    setNoteTitle('')
    setNoteBody('')
    setEditingNoteId(null)
    setNoteFormOpen(false)
  }

  function navigate(label) {
    setPage(label)
    setSearch('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const greeting = (() => {
    const hour = new Date().getHours()
    if (hour < 12) return 'Good morning'
    if (hour < 17) return 'Good afternoon'
    return 'Good evening'
  })()

  function updateSetup(key, value) {
    setSetup((current) => ({ ...current, [key]: value }))
  }

  function chooseSetupOption(key, value) {
    const current = Array.isArray(setup[key]) ? setup[key] : []
    updateSetup(key, current.includes(value) ? current.filter((item) => item !== value) : [...current, value])
  }

  function beginSetup() {
    setSetupStep(0)
    setFlow('setup')
  }

  function finishSetup() {
    const name = (setup.name || '').trim()
    setSetup((current) => ({ ...current, name }))
    setAuthName(name)
    setAuthUsername(String(setup.username || '').replace(/^@/, '').toLowerCase())
    setAuthMode('signup')
    setFlow('building')
  }

  async function submitAuth(event) {
    event.preventDefault()
    setAuthError('')
    setAuthBusy(true)
    try {
      const email = authEmail.trim().toLowerCase()
      const username = authUsername.trim().replace(/^@/, '').toLowerCase()

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
        throw new Error('Enter a valid email address.')
      }
      if (authPassword.length < 8) {
        throw new Error('Use a password with at least 8 characters.')
      }

      if (authMode === 'signup') {
        if (!authName.trim()) throw new Error('Please enter your name.')
        if (!/^[a-z0-9_.]{3,24}$/.test(username)) {
          throw new Error('Username must be 3–24 characters using letters, numbers, underscores or periods.')
        }
        if (!/[A-Z]/.test(authPassword) || !/[a-z]/.test(authPassword) || !/\d/.test(authPassword) || !/[^A-Za-z0-9]/.test(authPassword)) {
          throw new Error('Use uppercase and lowercase letters, a number and a symbol in your password.')
        }

        // Friendly pre-check; the database unique constraint remains the final authority.
        const { data: usernameAvailable, error: usernameCheckError } = await supabase.rpc(
          'is_username_available',
          { candidate_username: username },
        )
        if (usernameCheckError) {
          throw new Error('Username checking is not configured yet. Run atelier-auth.sql in Supabase SQL Editor, then try again.')
        }
        if (!usernameAvailable) throw new Error('That username is already taken. Please choose another one.')

        // The profiles table and trigger enforce username uniqueness even for simultaneous signups.
        const { data: signupData, error: signupError } = await supabase.auth.signUp({
          email,
          password: authPassword,
          options: { data: { name: authName.trim(), username } },
        })
        if (signupError) throw signupError
        if (!signupData.user) throw new Error('Supabase did not return a user. Check your project configuration.')
        if (!signupData.session) {
          throw new Error('Supabase created the account request but returned no session. Turn OFF Confirm email in Authentication → Sign In / Providers → Email, then retry with a new email address.')
        }

        const nextProfile = { name: signupData.user.user_metadata?.name || authName.trim(), username, email: signupData.user.email }
        setProfile(nextProfile)
        setSetup((current) => ({ ...current, name: nextProfile.name, username }))
        setFlow('dashboard')
      } else {
        const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({ email, password: authPassword })
        if (loginError) throw loginError
        if (!loginData.session || !loginData.user) throw new Error('Login did not return an active session. Please try again.')

        const nextProfile = {
          name: loginData.user.user_metadata?.name || loginData.user.email?.split('@')[0] || 'there',
          username: loginData.user.user_metadata?.username || '',
          email: loginData.user.email,
        }
        setProfile(nextProfile)
        setFlow('dashboard')
      }
      setAuthPassword('')
      setAuthError('')
    } catch (error) {
      console.error('Atelier authentication error:', { message: error?.message, status: error?.status, code: error?.code })
      const message = error?.message || 'Authentication failed. Please try again.'
      if (/already registered|already been registered|user already registered/i.test(message)) {
        setAuthError('An account with this email may already exist. Try logging in instead.')
      } else if (/username.*(duplicate|unique|taken|already exists)|duplicate key.*username/i.test(message)) {
        setAuthError('That username is already taken. Please choose another one.')
      } else if (/invalid login credentials/i.test(message)) {
        setAuthError('Email or password is incorrect.')
      } else if (/email not confirmed/i.test(message)) {
        setAuthError('This account still requires email confirmation. Turn off Confirm email in Supabase or use an already-confirmed account.')
      } else {
        setAuthError(message)
      }
    } finally {
      setAuthBusy(false)
    }
  }

  async function requestPasswordReset(event) {
    event.preventDefault()
    setAuthError('')
    const email = authEmail.trim().toLowerCase()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      setAuthError('Enter the email address for your account first.')
      return
    }
    setAuthBusy(true)
    try {
      const redirectTo = `${window.location.origin}/`
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo })
      if (error) throw error
      setAuthError('If an account exists for that email, a password-reset link has been requested. Check your inbox and spam folder.')
    } catch (error) {
      setAuthError(error?.message || 'Could not request a password reset. Please try again later.')
    } finally {
      setAuthBusy(false)
    }
  }

  async function saveNewPassword(event) {
    event.preventDefault()
    setAuthError('')
    if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[a-z]/.test(newPassword) || !/\d/.test(newPassword) || !/[^A-Za-z0-9]/.test(newPassword)) {
      setAuthError('Use at least 8 characters with uppercase, lowercase, a number and a symbol.')
      return
    }
    setAuthBusy(true)
    try {
      const { data: updateData, error } = await supabase.auth.updateUser({ password: newPassword })
      if (error) throw error
      if (!updateData.user) throw new Error('Password could not be updated. Request a new reset link and try again.')
      setNewPassword('')
      setRecoveryMode(false)
      setAuthPassword('')
      setAuthError('Your password has been updated. You can now continue to Atelier.')
      setFlow('dashboard')
    } catch (error) {
      setAuthError(error?.message || 'Could not update your password. Request a fresh reset link.')
    } finally {
      setAuthBusy(false)
    }
  }

  async function resetTemporaryData() {
    // Deliberately preserve workspace data and authentication.
    localStorage.removeItem('atelier-flow-v1')
    localStorage.removeItem('atelier-setup-v1')
    setSetup({})
    setSetupStep(0)
    setPage('Overview')
    setTaskFormOpen(false)
    setGoalFormOpen(false)
    setHabitFormOpen(false)
    setNoteFormOpen(false)
    setTaskTitle('')
    setTaskTime('')
    setTaskCategory('Personal')
    setGoalTitle('')
    setGoalDetail('')
    setHabitTitle('')
    setNoteTitle('')
    setNoteBody('')
    setEditingNoteId(null)
    setSearch('')
    setAuthName('')
    setAuthEmail('')
    setAuthPassword('')
    setAuthError('')
    setResetDialogOpen(false)

    try {
      const { data: { session }, error } = await supabase.auth.getSession()
      if (error) throw error
      setFlow(session?.user ? 'dashboard' : 'welcome')
      setToast('Temporary app state reset. Your saved workspace and login are preserved.')
    } catch {
      setFlow(profile?.email ? 'dashboard' : 'welcome')
      setToast('Temporary app state reset. Your saved workspace and login are preserved.')
    }
  }

  async function signOut() {
    setAuthBusy(true)
    const { error } = await supabase.auth.signOut()
    setAuthBusy(false)
    if (error) { setToast(error.message); return }
    setFlow('welcome')
    setAuthMode('login')
    setAuthPassword('')
    setAuthError('')
  }

  // Reusable list renderers are shared by Overview and the detail pages.
  function renderTaskList({ tasks, compact = false }) {
    if (!tasks.length) {
      return <div className="empty-state"><span className="empty-symbol">✦</span><strong>Nothing on this list yet</strong><span>Add a task to give your day some direction.</span></div>
    }

    return (
      <div className={`task-list ${compact ? 'task-list-compact' : ''}`}>
        {tasks.map((task) => (
          <div className={`task-row ${task.done ? 'task-done' : ''}`} key={task.id}>
            <label className="task-check-label" aria-label={`Mark ${task.title} ${task.done ? 'incomplete' : 'complete'}`}>
              <input type="checkbox" checked={task.done} onChange={() => toggleTask(task.id)} />
              <span className="custom-check"><Icon name="check" /></span>
            </label>
            <div className="task-copy">
              <strong>{task.title}</strong>
              <span><Icon name="clock" /> {task.time}</span>
            </div>
            <span className={`task-category category-${task.category.toLowerCase()}`}>{task.category}</span>
            {!compact && (
              <button className="subtle-icon-button task-delete" type="button" onClick={() => deleteTask(task.id)} aria-label={`Delete ${task.title}`} title="Delete task">
                <Icon name="trash" />
              </button>
            )}
          </div>
        ))}
      </div>
    )
  }

  function renderHabitList({ limit }) {
    const habits = limit ? data.habits.slice(0, limit) : data.habits
    if (!habits.length) {
      return <div className="empty-state"><span className="empty-symbol">✦</span><strong>Start with one habit</strong><span>Small routines make a difference.</span></div>
    }
    return (
      <div className="habit-list">
        {habits.map((habit) => {
          const done = todayHabits.includes(habit.id)
          return (
            <div className={`habit-row ${done ? 'habit-done' : ''}`} key={habit.id}>
              <button type="button" className="habit-main" onClick={() => toggleHabit(habit.id)} aria-pressed={done}>
                <span className="habit-symbol">{habit.icon}</span>
                <span className="habit-copy"><strong>{habit.title}</strong><span>{habit.detail}</span></span>
                <span className="habit-check"><Icon name="check" /></span>
              </button>
              {!limit && <button className="subtle-icon-button habit-delete" type="button" onClick={() => deleteHabit(habit.id)} aria-label={`Delete ${habit.title}`}><Icon name="trash" /></button>}
            </div>
          )
        })}
      </div>
    )
  }

  function renderAddTaskForm() {
    return (
      <form className="add-form task-add-form" onSubmit={addTask}>
        <label>Task name<input autoFocus value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} placeholder="What needs to get done?" maxLength={120} required /></label>
        <div className="form-row">
          <label>Time<input value={taskTime} onChange={(event) => setTaskTime(event.target.value)} placeholder="e.g. 10:30 AM" maxLength={30} /></label>
          <label>Category<select value={taskCategory} onChange={(event) => setTaskCategory(event.target.value)}><option>Personal</option><option>Work</option><option>Study</option><option>Planning</option></select></label>
        </div>
        <div className="form-actions"><button className="primary-button" type="submit">Save task</button><button className="cancel-button" type="button" onClick={() => setTaskFormOpen(false)}>Cancel</button></div>
      </form>
    )
  }

  if (flow === 'welcome') {
    return (
      <main className="entry-shell entry-welcome-screen cosmic-welcome">
        <CosmicGalaxy />
        <header className="cosmic-header">
          <a className="cosmic-brand" href="#top" onClick={(event) => event.preventDefault()}>
            atelier<span className="cosmic-period">.</span><span className="cosmic-brand-sparkle"> ✨</span>
          </a>
          <span>A little more clarity, every day.</span>
        </header>

        <section className="cosmic-welcome-content" id="top">
          <p className="cosmic-eyebrow">
YOUR UNIVERSE $ YOUR PACE $
</p>
          <h1>Open your<br /><em>Space ✨</em></h1>
          <p className="cosmic-description">
            Make room for what matters. Shape your goals, build thoughtful
            routines, and create a life that feels more like yours.
          </p>
          <div className="cosmic-actions">
            <button className="cosmic-start-button" type="button" onClick={beginSetup}>
              Open your Space <span aria-hidden="true">↗</span>
            </button>
            <button className="cosmic-signin-button" type="button" onClick={() => {
              setAuthMode('login')
              setFlow('auth')
            }}>
              I already have an account
            </button>
          </div>
          <p className="cosmic-footnote">✦ Your goals. Your rhythm. Your personal universe.</p>
        </section>

        <footer className="cosmic-footer">
          <span>atelier<span className="cosmic-period">.</span></span>
          <span>ALIGN · PLAN · GROW</span>
          <span>Designed for real life.</span>
        </footer>
      </main>
    )
  }

  if (flow === 'setup') {
    const pages = [
      { key: 'name', title: 'What should we call you?', desc: 'Your journey starts with you.', type: 'text', placeholder: 'Your name' },
      { key: 'username', title: 'Choose your username.', desc: 'A little space that is uniquely yours.', type: 'username', placeholder: 'Your username' },
      { key: 'gender', title: "What's your gender?", desc: 'Help us shape a more personal experience.', type: 'choice', options: ['Male', 'Female', 'Prefer not to say'] },
      { key: 'age', title: 'How old are you?', desc: 'Your plan should fit your current stage of life.', type: 'number', placeholder: '18' },
      { key: 'motivation', title: 'What motivates you?', desc: 'Choose all the things that keep you moving forward.', type: 'multi', options: ['Becoming my ideal self', 'Achieving ambitious goals', 'Seeing measurable progress', 'Proving something to myself', 'Freedom and independence', 'Personal growth'] },
      { key: 'primaryGoal', title: "What's your main goal?", desc: 'Select every outcome that matters to you.', type: 'multi', options: ['Become more disciplined', 'Improve my health and fitness', 'Excel in studies or career', 'Build better habits', 'Improve my mindset', 'Transform my lifestyle', 'Other'] },
      { key: 'referral', title: 'Where did you hear about Atelier?', desc: 'Every journey has a starting point.', type: 'choice', options: ['Instagram / TikTok', 'YouTube', 'Friends or family', 'Google / Search', 'Other'] },
      { key: 'goalHorizon', title: 'When would you like to see results?', desc: 'Choose a timeline that feels realistic for you.', type: 'choice', options: ['Within 30 days', '1–3 months', '3–6 months', '6–12 months', 'More than 1 year', 'Not sure'] },
      { key: 'level', title: 'Choose your level.', desc: 'Where do you feel you are right now?', type: 'choice', options: ['Just starting', 'Building momentum', 'Finding my rhythm', 'Consistent most days', 'Ready for a challenge'] },
      { key: 'time', title: 'How much time can you dedicate each day?', desc: 'We will respect the time you actually have.', type: 'choice', options: ['15–30 minutes', '30–60 minutes', '1–2 hours', 'More than 2 hours', 'My schedule changes'] },
      { key: 'focus', title: 'Choose your focus areas.', desc: 'Select all the areas you want to grow in.', type: 'multi', options: ['Studies and academics', 'Fitness and health', 'Productivity and discipline', 'Mindset and confidence', 'Career and skills', 'Habits and routines', 'Personal growth', 'Other'] },
      { key: 'obstacles', title: "What's your biggest obstacle?", desc: 'Select anything that tends to get in your way.', type: 'multi', options: ['Lack of consistency', 'Procrastination', 'Distractions and poor focus', 'Low motivation', 'Not enough time', 'Feeling overwhelmed', 'Not knowing where to start'] },
      { key: 'notes', title: 'Anything else we should know?', desc: 'Optional: tell us what would make this plan feel right for you.', type: 'textarea', placeholder: 'Share anything you want us to keep in mind…' },
    ]
    const current = pages[setupStep]
    const value = setup[current.key]
    const selected = Array.isArray(value) ? value : []
    const toggle = (option) => {
      const next = selected.includes(option) ? selected.filter((item) => item !== option) : [...selected, option]
      updateSetup(current.key, next)
    }
    const canContinue = () => {
      if (current.key === 'name') return !!String(value || '').trim()
      if (current.key === 'username') return /^[a-zA-Z0-9_.]{3,24}$/.test(String(value || '').replace(/^@/, ''))
      if (current.key === 'age') return Number(value) >= 13 && Number(value) <= 100
      if (current.type === 'multi') return selected.length > 0
      if (current.type === 'textarea') return true
      return !!String(value ?? '').trim()
    }
    return (
      <main className="atelier-onboarding">
        <div className="atelier-cosmos-backdrop" aria-hidden="true">
          <span className="atelier-nebula atelier-nebula-one" />
          <span className="atelier-nebula atelier-nebula-two" />
          <span className="atelier-gold-horizon" />
          <span className="atelier-stars" />
        </div>
        <header className="atelier-onboarding-header">
          <div className="atelier-mini-brand">atelier <span>✦</span></div>
          <div className="atelier-top-progress" aria-label={`Question ${setupStep + 1} of ${pages.length}`}>
            {pages.map((_, i) => <span key={i} className={i <= setupStep ? 'is-done' : ''} />)}
          </div>
          <button className="atelier-exit" type="button" onClick={() => setFlow('welcome')}>Exit ↗</button>
        </header>
        <section className="atelier-onboarding-content" key={setupStep}>
          <div className="atelier-question-kicker"><span /> YOUR JOURNEY · {String(setupStep + 1).padStart(2, '0')} / {pages.length}</div>
          <h1 className="atelier-question-title">{current.title}</h1>
          <p className="atelier-question-description">{current.desc}</p>
          <div className={`atelier-answer-panel ${current.type === 'multi' ? 'is-multiple' : ''}`}>
            {(current.type === 'text' || current.type === 'number') && (
              <label className="atelier-input-wrap">
                <span>{current.key === 'name' ? 'YOUR NAME' : 'YOUR AGE'}</span>
                <input autoFocus type={current.type} min={current.type === 'number' ? 13 : undefined} max={current.type === 'number' ? 100 : undefined}
                  value={value ?? ''} onChange={(event) => updateSetup(current.key, event.target.value)}
                  placeholder={current.placeholder} maxLength={current.type === 'text' ? 60 : undefined} />
              </label>
            )}
            {current.type === 'username' && (
              <label className="atelier-input-wrap">
                <span>YOUR USERNAME</span>
                <div className="atelier-username-input"><span>@</span><input autoFocus type="text" autoComplete="username"
                  value={String(value ?? '').replace(/^@/, '')}
                  onChange={(event) => updateSetup('username', event.target.value.replace(/^@+/, '').replace(/\s/g, '').slice(0, 24))}
                  placeholder={current.placeholder} maxLength={24} /></div>
                <small>3–24 characters · letters, numbers, underscores or periods</small>
              </label>
            )}
            {current.type === 'textarea' && (
              <label className="atelier-input-wrap"><span>YOUR NOTE <em>OPTIONAL</em></span>
                <textarea value={value ?? ''} onChange={(event) => updateSetup(current.key, event.target.value)} placeholder={current.placeholder} rows={4} maxLength={600} />
              </label>
            )}
            {(current.type === 'choice' || current.type === 'multi') && (
              <div className={`atelier-option-grid ${current.options.length === 3 ? 'three-options' : ''}`}>
                {current.options.map((option, index) => {
                  const active = current.type === 'multi' ? selected.includes(option) : value === option
                  return <button type="button" key={option} className={`atelier-option-card ${active ? 'selected' : ''}`}
                    onClick={() => current.type === 'multi' ? toggle(option) : updateSetup(current.key, option)}
                    aria-pressed={active}>
                    <span className="atelier-option-glyph">{active ? '✓' : ['✧', '◈', '✦', '☾', '◇', '✳'][index % 6]}</span>
                    <span>{option}</span><span className="atelier-option-check">{active ? '✓' : ''}</span>
                  </button>
                })}
              </div>
            )}
            {current.type === 'multi' && <p className="atelier-selection-hint">SELECT ALL THAT APPLY <span>{selected.length} selected</span></p>}
          </div>
          <div className="atelier-onboarding-actions">
            <button className="atelier-back-button" type="button" disabled={setupStep === 0} onClick={() => setSetupStep((step) => Math.max(0, step - 1))}>← <span>Back</span></button>
            <button className="atelier-continue-button" type="button" disabled={!canContinue()} onClick={() => {
              if (setupStep < pages.length - 1) setSetupStep((step) => step + 1)
              else setFlow('summary')
            }}>{setupStep === pages.length - 1 ? 'Review my answers' : 'Continue'} <span>↗</span></button>
          </div>
          <div className="atelier-bottom-note"><span>✦</span> 
YOUR UNIVERSE $ YOUR PACE $
</div>
        </section>
      </main>
    )
  }

  if (flow === 'summary') {
    const rows = [
      ['Name', setup.name || '—'], ['Username', setup.username ? `@${String(setup.username).replace(/^@/, '')}` : '—'],
      ['Gender', setup.gender || '—'], ['Age', setup.age || '—'], ['Motivation', (Array.isArray(setup.motivation) ? setup.motivation.join(', ') : setup.motivation) || '—'],
      ['Main goals', (Array.isArray(setup.primaryGoal) ? setup.primaryGoal.join(', ') : setup.primaryGoal) || '—'], ['How you found us', setup.referral || '—'],
      ['Results timeline', setup.goalHorizon || '—'], ['Current level', setup.level || '—'],
      ['Daily time', setup.time || '—'], ['Focus areas', (Array.isArray(setup.focus) ? setup.focus.join(', ') : setup.focus) || '—'],
      ['Obstacles', (Array.isArray(setup.obstacles) ? setup.obstacles.join(', ') : setup.obstacles) || '—'], ['Additional notes', setup.notes || 'Not provided'],
    ]
    return (
      <main className="atelier-onboarding">
        <div className="atelier-cosmos-backdrop" aria-hidden="true"><span className="atelier-nebula atelier-nebula-one" /><span className="atelier-nebula atelier-nebula-two" /><span className="atelier-gold-horizon" /><span className="atelier-stars" /></div>
        <header className="atelier-onboarding-header"><div className="atelier-mini-brand">atelier <span>✦</span></div><span className="atelier-summary-tag">YOUR PERSONAL BLUEPRINT</span><button className="atelier-exit" type="button" onClick={() => { setFlow('setup'); setSetupStep(12) }}>Edit ↗</button></header>
        <section className="atelier-summary-panel">
          <div className="atelier-question-kicker"><span /> BEFORE WE BEGIN</div><h1 className="atelier-question-title">Your answers <em>summary.</em></h1>
          <p className="atelier-question-description">A little picture of where you are—and where you want to go.</p>
          <div className="atelier-summary-grid">{rows.map(([label, answer], i) => <div className="atelier-summary-row" key={label}><span className="atelier-summary-number">{String(i + 1).padStart(2, '0')}</span><div><small>{label}</small><strong>{String(answer)}</strong></div><button type="button" onClick={() => { setFlow('setup'); setSetupStep([0,1,2,3,4,5,6,7,8,9,10,11,12][i]) }} aria-label={`Edit ${label}`}>↗</button></div>)}</div>
          <div className="atelier-onboarding-actions"><button className="atelier-back-button" type="button" onClick={() => { setFlow('setup'); setSetupStep(12) }}>← <span>Back</span></button><button className="atelier-continue-button" type="button" onClick={() => { setAuthName(setup.name || ''); setFlow('building') }}>Create my roadmap <span>✦</span></button></div>
        </section>
      </main>
    )
  }

  
  
  if (flow === 'building') {
    const stages = [
      'Understanding Your Goals',
      'Reviewing Your Habits',
      'Finding Your Rhythm',
      'Building Your Plan',
      'Preparing Your Next Steps',
    ];

    return (
      <main className="atelier-building-scene">
        <div className="atelier-cosmos-backdrop" aria-hidden="true">
          <span className="atelier-nebula atelier-nebula-one" />
          <span className="atelier-nebula atelier-nebula-two" />
          <span className="atelier-gold-horizon" />
          <span className="atelier-stars" />
        </div>

        <header className="atelier-building-header">
          <div className="atelier-mini-brand">
            atelier <span>✦</span>
          </div>

          <div className="atelier-building-top-progress">
            {stages.map((_, index) => (
              <span
                key={index}
                className={
                  buildingProgress >= (index + 1) * 20
                    ? 'is-lit'
                    : ''
                }
              />
            ))}
          </div>

          <button
            className="atelier-building-signin"
            type="button"
            onClick={() => {
              setAuthMode('login');
              setFlow('auth');
            }}
          >
            Sign In
          </button>
        </header>

        <section className="atelier-building-main" aria-live="polite">
          <div className="atelier-building-title">
            <h1>
              Building your <em>personal plan.</em>
            </h1>
            <p>
              Turning your goals, daily habits, and available time
              <br className="atelier-desktop-break" />
              into a routine that works for real life.
            </p>
          </div>

          <div className="atelier-building-orbit" aria-hidden="true">
            <div className="atelier-building-orbit-ring orbit-one" />
            <div className="atelier-building-orbit-ring orbit-two" />
            <div className="atelier-building-orbit-ring orbit-three" />
            <div className="atelier-building-planet">
              <span>✦</span>
            </div>
          </div>

          <div className="atelier-building-progress-area">
            <div
              className="atelier-building-progress-line"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={buildingProgress}
            >
              <div
                className="atelier-building-progress-fill"
                style={{ width: `${buildingProgress}%` }}
              />
            </div>
            <span className="atelier-building-percent">
              {buildingProgress}%
            </span>
          </div>

          <div className="atelier-building-stages">
            {stages.map((label, index) => {
              const start = index * 20;
              const end = (index + 1) * 20;
              const complete = buildingProgress >= end;
              const active =
                buildingProgress >= start &&
                buildingProgress < end;

              return (
                <React.Fragment key={label}>
                  <div
                    className={`atelier-building-stage ${
                      complete
                        ? 'is-complete'
                        : active
                          ? 'is-active'
                          : 'is-pending'
                    }`}
                  >
                    <span className="atelier-stage-node">
                      {complete ? (
                        '✓'
                      ) : active ? (
                        <span className="atelier-stage-pulse" />
                      ) : null}
                    </span>
                    <span>{label}</span>
                  </div>

                  {index < stages.length - 1 && (
                    <div
                      className={`atelier-stage-connector ${
                        buildingProgress >= end
                          ? 'is-complete'
                          : 'is-pending'
                      }`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </section>
      </main>
    );
  }

 
  if (flow === 'analysis') {
    const levelMap = {
      'Just starting': 3,
      'Building momentum': 4,
      'Finding my rhythm': 5,
      'Consistent most days': 7,
      'Ready for a challenge': 8,
    }

    const rating = Math.max(1, Math.min(10, Number(setup.selfRating) || Number(setup.level) || levelMap[setup.level] || 5))
    const focusAreas = Array.isArray(setup.focus) ? setup.focus : []
    const obstacleAreas = Array.isArray(setup.obstacles) ? setup.obstacles : []
    const focusCount = focusAreas.length
    const currentMomentum = Math.min(95, rating * 10 + 12)
    const roomToGrow = Math.min(99, rating * 10 + 31)
    const durationLabel = setup.goalHorizon || '3–6 months'

    const improvements = [
      {
        icon: '◷',
        title: 'Time Management',
        detail: obstacleAreas.includes('Lack of time')
          ? 'You often feel busy and struggle to find consistent time.'
          : 'Protect a small, consistent block of time each day.',
        color: 'time',
      },
      {
        icon: '♡',
        title: 'Healthy Habits',
        detail: obstacleAreas.includes('Lack of consistency')
          ? 'Inconsistent routines can make progress harder to maintain.'
          : 'Build routines that support your energy and wellbeing.',
        color: 'habits',
      },
      {
        icon: '✧',
        title: 'Motivation',
        detail: obstacleAreas.includes('Low motivation')
          ? 'You sometimes find it hard to stay consistent.'
          : 'Connect daily actions to the reason behind your goals.',
        color: 'motivation',
      },
      {
        icon: '↗',
        title: focusAreas[0] || 'Personal Growth',
        detail: focusAreas.length
          ? `Build consistent progress in ${focusAreas.slice(0, 2).join(' and ')}.`
          : 'Choose a clear priority and build from there.',
        color: 'focus',
      },
    ]

    const sidebarSteps = [
      'About You',
      'Goals',
      'Lifestyle',
      'Time',
      'Challenges',
      'Timeline',
      'Summary',
      'Self Rating',
      'Analysis',
    ]

    return (
      <main className="atelier-reference-analysis">
        <div className="atelier-reference-wallpaper" aria-hidden="true" />

        <aside className="atelier-reference-sidebar">
          <div className="atelier-reference-logo">
            atelier <span>✦</span>
          </div>

          <nav className="atelier-reference-nav" aria-label="Your setup progress">
            {sidebarSteps.map((label, index) => (
              <div
                className={`atelier-reference-nav-item ${label === 'Analysis' ? 'active' : ''}`}
                key={label}
              >
                <span className="atelier-reference-nav-icon">
                  {label === 'Analysis' ? '●' : '✓'}
                </span>
                <span>{label}</span>
              </div>
            ))}
          </nav>

          <div className="atelier-reference-sidebar-quote">
            <p>A better you</p>
            <p>is a more</p>
            <p>powerful future.</p>
            <span>────</span>
          </div>
        </aside>

        <div className="atelier-reference-main">
          <header className="atelier-reference-topbar">
            <div className="atelier-reference-top-spacer" />
            <div className="atelier-reference-theme-mark">☼ ◐</div>
            <button
              className="atelier-reference-signin"
              type="button"
              onClick={() => {
                setAuthMode('login')
                setAuthError('')
                setFlow('auth')
              }}
            >
              Sign In
            </button>
          </header>

          <section className="atelier-reference-content">
            <div className="atelier-reference-intro">
              <div className="atelier-reference-eyebrow">
                ANALYSIS COMPLETE
              </div>

              <h1>
                Here’s your <em>starting point.</em>
              </h1>

              <p>
                Based on your answers, we’ve identified your priorities and
                areas for growth. Your personal blueprint is ready to guide
                your next chapter.
              </p>
            </div>

            <div className="atelier-reference-cards">
              <article className="atelier-reference-card atelier-reference-rating">
                <div className="atelier-reference-card-title">
                  <span>✧</span> OVERALL RATING
                </div>

                <div
                  className="atelier-reference-score-ring"
                  style={{ '--score': `${rating * 10}%` }}
                  role="img"
                  aria-label={`Overall rating ${rating} out of 10`}
                >
                  <div className="atelier-reference-score-inner">
                    <div>
                      <strong>{rating}</strong><span>/10</span>
                    </div>
                    <small>Current Self</small>
                  </div>
                </div>

                <p className="atelier-reference-rating-copy">
                  You have a starting point to build from. With a clear plan
                  and consistent actions, you can make meaningful progress.
                </p>
              </article>

              <article className="atelier-reference-card atelier-reference-blueprint atelier-vs-average-card">
  <div className="atelier-reference-card-title">
    <span className="atelier-average-heading-icon">▥</span>
    YOU VS AVERAGE
  </div>

  <div className="atelier-average-layout">
    {/* LEFT: Percentage bars */}
    <div className="atelier-average-chart">
      <div className="atelier-average-bars">
        <div className="atelier-average-bar-column">
          <strong className="atelier-average-value">
            {currentMomentum}%
          </strong>

          <div className="atelier-average-bar-track">
            <div
              className="atelier-average-bar atelier-average-bar-you"
              style={{ height: `${currentMomentum}%` }}
            />
          </div>

          <span className="atelier-average-label">You</span>
        </div>

        <div className="atelier-average-bar-column">
          <strong className="atelier-average-value">
            41%
          </strong>

          <div className="atelier-average-bar-track">
            <div
              className="atelier-average-bar atelier-average-bar-average"
              style={{ height: '41%' }}
            />
          </div>

          <span className="atelier-average-label">Average</span>
        </div>
      </div>
    </div>

    {/* RIGHT: Comparison explanation */}
    <div className="atelier-average-insight">
      <p>
        Your current score is compared with a
        <strong> 41% reference benchmark.</strong>
      </p>

      <p className="atelier-average-difference">
        {currentMomentum >= 41
          ? `${currentMomentum - 41} percentage points above`
          : `${41 - currentMomentum} percentage points below`}
      </p>

      <p className="atelier-average-supporting">
        the reference average.
      </p>

      <div className="atelier-average-note">
        <span className="atelier-average-person" aria-hidden="true">
          ♙
        </span>

        <div>
          <p>
            Your current momentum is <strong>{currentMomentum}%</strong>,
            based on your self-rating.
          </p>

          <p>
            A practical next milestone is to build toward
            <strong> 60%</strong> through consistent, achievable actions.
          </p>
        </div>
      </div>
    </div>
  </div>

  <p className="atelier-average-disclaimer">
    The average is an illustrative reference, not verified population data.
    Your score is a planning indicator, not a scientific measurement.
  </p>
</article>
              <article className="atelier-reference-card atelier-reference-improvements">
                <div className="atelier-reference-card-title">
                  <span>↗</span> KEY AREAS FOR IMPROVEMENT
                </div>

                <div className="atelier-reference-improvement-list">
                  {improvements.map((item) => (
                    <div className="atelier-reference-improvement" key={item.title}>
                      <span className={`atelier-reference-improvement-icon ${item.color}`}>
                        {item.icon}
                      </span>
                      <div>
                        <strong>{item.title}</strong>
                        <p>{item.detail}</p>
                      </div>
                      <span className="atelier-reference-arrow">→</span>
                    </div>
                  ))}
                </div>
              </article>
            </div>

            <article className="atelier-reference-potential">
              <div className="atelier-reference-potential-art" aria-hidden="true" />

              <div className="atelier-reference-potential-content">
                <div className="atelier-reference-potential-heading">
                  <span>✧</span>
                  <div>
                    <div className="atelier-reference-eyebrow">
                      YOUR POTENTIAL
                    </div>
                    <h2>
                      Your next chapter starts with <em>one clear step.</em>
                    </h2>
                    <p>
                      Your personal blueprint brings your goals, routines,
                      and everyday challenges together in one achievable plan.
                    </p>
                  </div>
                </div>

                <div className="atelier-reference-potential-features">
                  <div><span>◎</span><section><strong>Clear Goals</strong><small>Personalised for you</small></section></div>
                  <div><span>▥</span><section><strong>Structured Plan</strong><small>Step-by-step guidance</small></section></div>
                  <div><span>♕</span><section><strong>Real Progress</strong><small>Track your growth</small></section></div>
                </div>
              </div>

              <button
                className="atelier-reference-view-plan"
                type="button"
                onClick={() => setFlow('plan')}
              >
                View My Plan <span>→</span>
              </button>
            </article>

            <div className="atelier-reference-bottom-actions">
              <button type="button" onClick={() => setFlow('summary')}>
                ← Back to answers
              </button>
              <span>{focusCount} focus areas selected</span>
            </div>
          </section>
        </div>
      </main>
    )
  }


  
if (flow === 'plan') {
  const focus = setup.focus?.length
    ? setup.focus
    : ['Habits and routines']

  const time = setup.time || '30–60 minutes'
  const horizon = setup.goalHorizon || '3–6 months'

  const duration =
    horizon === 'Within 30 days' ? 30 :
    horizon === '1–3 months' ? 90 :
    horizon === '3–6 months' ? 180 :
    horizon === '6–12 months' ? 365 :
    horizon === 'More than 1 year' ? 730 : 90

  const phaseDays = [
    1,
    Math.max(7, Math.round(duration / 3)),
    Math.max(14, Math.round(duration * 2 / 3)),
    duration,
  ]

  const phases = [
    {
      day: phaseDays[0],
      title: 'Build your base',
      detail:
        'Create a simple routine and choose the smallest habits you can repeat.',
      image: roadmapBase,
      label: 'START SMALL',
    },
    {
      day: phaseDays[1],
      title: 'Build momentum',
      detail:
        'Make your routine more consistent and track the wins that matter.',
      image: roadmapMomentum,
      label: 'STAY CONSISTENT',
    },
    {
      day: phaseDays[2],
      title: 'See real changes',
      detail:
        'Review what is working, adjust what is not, and increase the challenge gradually.',
     image: roadmapProgress,
      label: 'TRACK PROGRESS',
    },
    {
      day: phaseDays[3],
      title: 'A stronger you',
      detail:
        'Reflect on your progress and choose the next level that fits your life.',
     image: roadmapStronger,  
      label: 'LEVEL UP',
    },
  ]

  return (
    <main className="atelier-cinematic-screen atelier-roadmap-screen">
      <div className="atelier-cosmos-backdrop" aria-hidden="true">
        <span className="atelier-nebula atelier-nebula-one" />
        <span className="atelier-nebula atelier-nebula-two" />
        <span className="atelier-gold-horizon" />
        <span className="atelier-stars" />
      </div>

      <header className="atelier-cinematic-header">
        <div className="atelier-mini-brand">
          atelier <span>✦</span>
        </div>

        <div className="atelier-roadmap-top-label">
          YOUR PERSONAL ROADMAP
        </div>

        <button
          className="atelier-exit"
          type="button"
          onClick={() => {
            setAuthMode('login')
            setFlow('auth')
          }}
        >
          Sign in
        </button>
      </header>

      <section className="atelier-roadmap-content">
        <div className="atelier-question-kicker">
          YOUR NEXT {duration} DAYS
        </div>

        <h1 className="atelier-cinematic-title">
          A stronger you, <em>step by step.</em>
        </h1>

        <p className="atelier-cinematic-subtitle">
          A practical {duration}-day starting roadmap shaped around your
          goals and available time.
        </p>

       
<div className="atelier-roadmap-timeline">
  {phases.map((phase, i) => (
    <div className="atelier-roadmap-phase" key={phase.title}>
      <div className="atelier-phase-day">
        {i === 0 ? 'DAY 1' : `DAY ${phase.day}`}
      </div>

      <span className="atelier-phase-node">
        {i === 0 ? '○' : '✦'}
      </span>

      <article className="atelier-phase-card">
        <div className={`atelier-phase-art phase-art-${i + 1}`}>
          <img
            src={phase.image}
            alt=""
            className="atelier-phase-image"
          />

          <span className="atelier-phase-art-label">
            PHASE {String(i + 1).padStart(2, '0')}
          </span>
        </div>

        <div className="atelier-phase-copy">
          <h2>{phase.title}</h2>
          <p>{phase.detail}</p>
        </div>
      </article>
    </div>
  ))}
</div>

        <div className="atelier-roadmap-focus-strip">
          {focus.slice(0, 4).map((item, i) => (
            <div key={item}>
              <span>{['✧', '◎', 'ϟ', '♡'][i]}</span>
              <strong>{item}</strong>
            </div>
          ))}
        </div>

        <div className="atelier-roadmap-footer-actions">
          <button
            className="atelier-back-button"
            type="button"
            onClick={() => setFlow('analysis')}
          >
            ← Back to analysis
          </button>

          <button
            className="atelier-continue-button"
            type="button"
            onClick={() => {
              setAuthName(setup.name || '')
              setAuthUsername(String(setup.username || '').replace(/^@/, '').toLowerCase())
              setAuthMode('signup')
              setFlow('auth')
            }}
          >
            Save My Space <span>→</span>
          </button>
        </div>

        <p className="atelier-roadmap-disclaimer">
          A personalised starting framework based on your answers.
          Review your milestones as you learn what works for you.
        </p>
      </section>
    </main>
  )
}


  if (flow === 'auth') {
    return (
      <main className="entry-shell auth-shell">
        <div className="entry-stars" aria-hidden="true" />
        <div className="entry-top">
          <button className="flow-brand" type="button" onClick={() => { setRecoveryMode(false); setAuthError(''); setFlow(authMode === 'signup' ? 'plan' : 'welcome') }}>
            <span className="sparkle-mark"><Icon name="sparkle" /></span>atelier<span>.</span>
          </button>
          <span className="entry-caption">Your space is waiting.</span>
        </div>
        <section className="auth-card auth-card-animated">
          <div className="auth-emblem"><Icon name="sparkle" /></div>
          <div className="entry-kicker"><span /> {recoveryMode ? 'RESET YOUR PASSWORD' : authMode === 'signup' ? 'MAKE IT YOURS' : 'WELCOME BACK'}</div>
          <h1>{recoveryMode ? 'Choose a new password.' : authMode === 'signup' ? 'Create your space.' : 'Good to see you again.'}</h1>
          <p>{recoveryMode ? 'Choose a strong new password to secure your Atelier account.' : authMode === 'signup' ? 'Create an account with a unique username and password.' : 'Log in to your Atelier space.'}</p>

          {recoveryMode ? (
            <form className="auth-form" onSubmit={saveNewPassword}>
              <label className="field-label">New password<input type="password" autoComplete="new-password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} minLength={8} required /></label>
              {authError && <p className="auth-error" role="alert">{authError}</p>}
              <button className="entry-primary auth-submit" type="submit" disabled={authBusy}>{authBusy ? 'Saving…' : 'Update password'} <Icon name="arrowRight" /></button>
            </form>
          ) : authMode === 'forgot' ? (
            <form className="auth-form" onSubmit={requestPasswordReset}>
              <label className="field-label">Email address<input type="email" autoComplete="email" value={authEmail} onChange={(event) => setAuthEmail(event.target.value)} placeholder="you@example.com" required /></label>
              {authError && <p className="auth-error" role="alert">{authError}</p>}
              <button className="entry-primary auth-submit" type="submit" disabled={authBusy}>{authBusy ? 'Requesting…' : 'Send reset link'} <Icon name="arrowRight" /></button>
              <button className="auth-secondary" type="button" onClick={() => { setAuthMode('login'); setAuthError('') }}>Back to log in</button>
            </form>
          ) : (
            <form className="auth-form" onSubmit={submitAuth}>
              {authMode === 'signup' && <>
                <label className="field-label">Your name<input autoComplete="name" value={authName} onChange={(event) => setAuthName(event.target.value)} placeholder="Your name" maxLength={60} required /></label>
                <label className="field-label">Unique username<div className="atelier-username-input"><span>@</span><input autoComplete="username" value={authUsername} onChange={(event) => setAuthUsername(event.target.value.toLowerCase().replace(/^@+/, '').replace(/\s/g, '').slice(0, 24))} placeholder="yourname" minLength={3} maxLength={24} required /></div><small>3–24 characters: letters, numbers, underscores or periods. Usernames are case-insensitive.</small></label>
              </>}
              <label className="field-label">Email address<input type="email" autoComplete="email" value={authEmail} onChange={(event) => setAuthEmail(event.target.value)} placeholder="you@example.com" required /></label>
              <label className="field-label">Password<input type="password" autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'} value={authPassword} onChange={(event) => setAuthPassword(event.target.value)} placeholder="Use a strong password" minLength={8} required />
                {authMode === 'signup' && <div className="password-strength"><div className="strength-lines">{[1,2,3,4].map((level) => <span key={level} className={passwordStrength >= level ? `filled strength-${passwordStrength}` : ''} />)}</div><div className="strength-caption">{passwordStrength === 0 ? '🔒 Add a password' : passwordStrength === 1 ? '😬 Weak' : passwordStrength === 2 ? '😐 Fair' : passwordStrength === 3 ? '🙂 Good' : '🛡️ Strong'}</div><small>Use 8+ characters, mixed case, a number and a symbol.</small></div>}
              </label>
              {authError && <p className="auth-error" role="alert">{authError}</p>}
              <button className="entry-primary auth-submit" type="submit" disabled={authBusy}>{authBusy ? 'Please wait…' : authMode === 'signup' ? 'Create account' : 'Log in'} <Icon name="arrowRight" /></button>
              {authMode === 'login' && <button className="auth-secondary" type="button" onClick={() => { setAuthMode('forgot'); setAuthError('') }}>Forgot password?</button>}
            </form>
          )}
          {!recoveryMode && authMode !== 'forgot' && <div className="auth-switch">{authMode === 'signup' ? 'Already have a space?' : 'New to Atelier?'} <button type="button" onClick={() => { setAuthMode(authMode === 'signup' ? 'login' : 'signup'); setAuthError('') }}>{authMode === 'signup' ? 'Log in' : 'Create an account'}</button></div>}
          <div className="auth-notice"><Icon name="shield" /><span>Passwords are managed securely by Supabase. Atelier never stores your password in browser storage.</span></div>
        </section>
        <footer className="entry-footer"><span>atelier<span className="wordmark-period">.</span></span><span>ALIGN · PLAN · GROW</span><span>Private by intention.</span></footer>
      </main>
    )
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" type="button" onClick={() => navigate('Overview')} aria-label="atelier home">
          <span className="brand-mark"><Icon name="sparkle" /></span>
          <span className="brand-name">atelier<span>.</span></span>
        </button>

        <div className="workspace-label">YOUR WORKSPACE</div>
        <nav className="main-nav" aria-label="Main navigation">
          {navItems.map((item) => (
            <button
              type="button"
              key={item.label}
              className={`nav-item ${page === item.label ? 'active' : ''}`}
              onClick={() => navigate(item.label)}
              aria-current={page === item.label ? 'page' : undefined}
            >
              <span className="nav-icon"><Icon name={item.icon} /></span>
              <span>{item.label}</span>
              {item.count > 0 && <span className="nav-count">{item.count}</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="upgrade-card">
            <span className="upgrade-spark"><Icon name="sparkle" /></span>
            <strong>Your space, your pace.</strong>
            <p>Small steps make remarkable days. Keep going, one thing at a time.</p>
          </div>
          <button className="reset-data-button" type="button" onClick={() => setResetDialogOpen(true)}>
            <Icon name="rotate" />
            <span>Reset temporary data</span>
          </button>
          <div className="profile-row">
            <span className="avatar">a</span>
            <span className="profile-copy"><strong>{profile.name || setup.name || 'My workspace'}</strong><span>{profile.email || 'Personal space'}</span></span>
            <button className="profile-menu" type="button" onClick={signOut} aria-label="Log out" title="Log out">↗</button>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{page}</strong></div>
          <div className="topbar-actions">
            <span className="today-chip"><span className="status-dot" /> Your personal space</span>
            <button className="icon-button" type="button" onClick={() => setToast('Your changes save automatically on this device.')} aria-label="Storage information" title="Storage information"><Icon name="bell" /></button>
            <span className="top-avatar">{(profile.name || setup.name || 'a').slice(0, 1).toLowerCase()}</span>
          </div>
        </header>

        <div className="page-content">
          {/* Feature screens live in their own files under src/features. */}
          {page === 'Overview' && (
            <Overview
              data={data} profile={profile} setup={setup} greeting={greeting}
              completedTasks={completedTasks} taskProgress={taskProgress}
              completedHabits={completedHabits} openTasks={openTasks}
              navigate={navigate} renderTaskList={renderTaskList}
              setTaskFormOpen={setTaskFormOpen} renderHabitList={renderHabitList}
              setGoalFormOpen={setGoalFormOpen} setNoteFormOpen={setNoteFormOpen}
              setEditingNoteId={setEditingNoteId} setNoteTitle={setNoteTitle}
              setNoteBody={setNoteBody} editNote={editNote} Icon={Icon} formatDate={formatDate}
            />
          )}
          {page === 'My tasks' && (
            <Tasks
              data={data} completedTasks={completedTasks} search={search}
              setSearch={setSearch} taskFormOpen={taskFormOpen}
              setTaskFormOpen={setTaskFormOpen} renderAddTaskForm={renderAddTaskForm}
              renderTaskList={renderTaskList} filteredTasks={filteredTasks} Icon={Icon}
            />
          )}
          {page === 'Goals' && (
            <Goals
              data={data} goalFormOpen={goalFormOpen} setGoalFormOpen={setGoalFormOpen}
              goalTitle={goalTitle} setGoalTitle={setGoalTitle} goalDetail={goalDetail}
              setGoalDetail={setGoalDetail} addGoal={addGoal} deleteGoal={deleteGoal}
              adjustGoal={adjustGoal} Icon={Icon}
            />
          )}
          {page === 'Habits' && (
            <Habits
              data={data}
              completedHabits={completedHabits}
              habitFormOpen={habitFormOpen}
              setHabitFormOpen={setHabitFormOpen}
              habitTitle={habitTitle}
              setHabitTitle={setHabitTitle}
              habitDetail={habitDetail}
              setHabitDetail={setHabitDetail}
              addHabit={addHabit}
              toggleHabit={toggleHabit}
              deleteHabit={deleteHabit}
              formatDate={formatDate}
              renderHabitList={renderHabitList}
              Icon={Icon}
            />
          )}
          {page === 'Notes' && (
            <Notes
              data={data} noteFormOpen={noteFormOpen} setNoteFormOpen={setNoteFormOpen}
              editingNoteId={editingNoteId} setEditingNoteId={setEditingNoteId}
              noteTitle={noteTitle} setNoteTitle={setNoteTitle} noteBody={noteBody}
              setNoteBody={setNoteBody} saveNote={saveNote} resetNoteForm={resetNoteForm}
              editNote={editNote} deleteNote={deleteNote} navigate={navigate} Icon={Icon}
            />
          )}

          <footer className="page-footer"><span>Made for a life with a little more clarity.</span><span>One step at a time <span className="footer-heart">✦</span></span></footer>
        </div>
      </main>

      {resetDialogOpen && (
        <div className="reset-dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setResetDialogOpen(false) }}>
          <section className="reset-dialog" role="dialog" aria-modal="true" aria-labelledby="reset-dialog-title">
            <span className="reset-dialog-icon"><Icon name="rotate" /></span>
            <div className="section-kicker">ATELIER · SETTINGS</div>
            <h2 id="reset-dialog-title">Reset temporary data?</h2>
            <p>This resets onboarding choices, open forms, search and temporary verification state. Your tasks, goals, habits, notes and login will stay safe.</p>
            <div className="reset-dialog-actions">
              <button className="cancel-button" type="button" onClick={() => setResetDialogOpen(false)}>Cancel</button>
              <button className="primary-button" type="button" onClick={resetTemporaryData}>Reset temporary data</button>
            </div>
          </section>
        </div>
      )}
      {toast && <div className="toast-message" role="status"><span className="toast-check"><Icon name="check" /></span>{toast}<button type="button" onClick={() => setToast('')} aria-label="Dismiss notification"><Icon name="close" /></button></div>}
    </div>
  )
}

export default App
