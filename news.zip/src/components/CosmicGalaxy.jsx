
import { useEffect, useRef } from 'react'
import './CosmicGalaxy.css'

export default function CosmicGalaxy() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d', { alpha: false })
    if (!canvas || !ctx) return

    const host = canvas.closest('.cosmic-welcome') || canvas.parentElement
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)')
    const rand = (min, max) => min + Math.random() * (max - min)

    let width = 1
    let height = 1
    let dpr = 1
    let elapsed = 0
    let previousTime = 0
    let frameId = 0
    let stars = []
    let galaxyDust = []
    let logoParticles = [] 
    let meteors = []
    let ripples = []
    let planets = []
    let resizeObserver
    let logoReady = false

    const pointer = { x: -1000, y: -1000, active: false }
    const MAX_DPR = 1.5

    function buildLogoParticles() {
      const offscreen = document.createElement('canvas')
      const sample = offscreen.getContext('2d')
      if (!sample) return

      offscreen.width = Math.ceil(width)
      offscreen.height = Math.ceil(height)

      const fontSize = Math.min(120, Math.max(66, width * 0.092))
      const centerX = width * 0.5
      const centerY = height * 0.37

      sample.clearRect(0, 0, width, height)
      sample.fillStyle = '#fff'
      sample.textAlign = 'center'
      sample.textBaseline = 'middle'
      sample.font = `500 ${fontSize}px Georgia, "Times New Roman", serif`
      sample.fillText('atelier', centerX, centerY, width * 0.82)

      const pixels = sample.getImageData(0, 0, offscreen.width, offscreen.height).data
      const points = []
      const step = width < 600 ? 3 : 3.4

      for (let y = 0; y < height; y += step) {
        for (let x = 0; x < width; x += step) {
          const index = (Math.floor(y) * offscreen.width + Math.floor(x)) * 4
          if (pixels[index + 3] > 110) points.push({ x, y })
        }
      }

      // Shuffle so the logo forms organically instead of drawing letter by letter.
      for (let i = points.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[points[i], points[j]] = [points[j], points[i]]
      }

      const selected = points.slice(0, width < 600 ? 1700 : 2600)
      if (!selected.length) return

      const minX = Math.min(...selected.map(p => p.x))
      const maxX = Math.max(...selected.map(p => p.x))
      const minY = Math.min(...selected.map(p => p.y))
      const maxY = Math.max(...selected.map(p => p.y))

      // These target dimensions align with the top-left brand in the CSS.
      const targetWidth = width < 600 ? 103 : 132
      const targetHeight = width < 600 ? 30 : 39
      const targetLeft = width < 600 ? 25 : 82
      const targetTop = width < 600 ? 34 : 51

      
logoParticles = selected.map((point) => {
  const angle = rand(0, Math.PI * 2)
  const radius = rand(
    Math.min(width, height) * 0.16,
    Math.max(width, height) * 0.65,
  )

  const spiral = radius * 0.018
  const startAngle = angle + spiral
  const goldChance = Math.random()

  return {
    startX: width * 0.5 + Math.cos(startAngle) * radius,
    startY: height * 0.42 + Math.sin(startAngle) * radius * 0.62,
    centerX: point.x,
    centerY: point.y,
    endX: targetLeft +
      ((point.x - minX) / Math.max(1, maxX - minX)) * targetWidth,
    endY: targetTop +
      ((point.y - minY) / Math.max(1, maxY - minY)) * targetHeight,
    size: rand(0.55, 1.55),
    phase: rand(0, Math.PI * 2),
    gold: goldChance < 0.48,

        }
      })
    }


function createUniverse() {
  const area = width * height
  const count = Math.min(
    4200,
    Math.max(1800, Math.floor(area / 300)),
  )

  stars = Array.from(
    { length: Math.min(650, Math.max(260, Math.floor(area / 1500))) },
    () => ({
      x: rand(0, width),
      y: rand(0, height),
      size: rand(0.35, 1.2),
      alpha: rand(0.25, 0.9),
      phase: rand(0, Math.PI * 2),
      gold: Math.random() < 0.42,
      speed: rand(0.5, 1.8),
    }),
  )

  // Dense particles follow four curved spiral arms.
  galaxyDust = Array.from({ length: count }, () => {
    const arm = Math.floor(Math.random() * 4)
    const maxRadius = Math.min(width * 0.48, height * 0.58)
    const radius = Math.pow(Math.random(), 0.72) * maxRadius
    const armWidth = 0.08 + radius * 0.00022
    const angle = arm * (Math.PI / 2) + rand(-armWidth, armWidth)

    return {
      radius,
      angle,
      arm,
      size: rand(0.35, radius < 65 ? 1.9 : 1.15),
      alpha: rand(0.22, 0.95),
      phase: rand(0, Math.PI * 2),
      orbit: rand(0.012, 0.055) * (Math.random() < 0.5 ? -1 : 1),
      gold: Math.random() < 0.32,
      violet: Math.random() < 0.22,
      bright: Math.random() < 0.045,
      dust: Math.random() < 0.55,
      depth: rand(0.42, 1),
    }
  })

  // Planets are deliberately sabled: the spiral galaxy is the focus.
  planets = []
}


    function resize() {
      const rect = canvas.getBoundingClientRect()
      width = Math.max(1, rect.width)
      height = Math.max(1, rect.height)
      dpr = Math.min(window.devicePixelRatio || 1, MAX_DPR)

      canvas.width = Math.round(width * dpr)
      canvas.height = Math.round(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      createUniverse()
      buildLogoParticles()
    }

    function pointerMove(event) {
      const rect = canvas.getBoundingClientRect()
      pointer.x = event.clientX - rect.left
      pointer.y = event.clientY - rect.top
      pointer.active = true
    }

    function pointerLeave() {
      pointer.active = false
    }

    
function pointerClick(event) {
  const rect = canvas.getBoundingClientRect()
  const x = event.clientX - rect.left
  const y = event.clientY - rect.top

  ripples.push({
    x,
    y,
    age: 0,
    life: 1.25,
  })

  // Launch a meteor from the edge toward the exact click location.
  const fromLeft = Math.random() < 0.5
  const startX = fromLeft ? -45 : width + 45
  const startY = rand(-20, height * 0.45)
  const dx = x - startX
  const dy = y - startY
  const distance = Math.hypot(dx, dy) || 1
  const speed = 850

  meteors.push({
    x: startX,
    y: startY,
    vx: (dx / distance) * speed,
    vy: (dy / distance) * speed,
    age: 0,
    life: Math.min(1.5, distance / speed),
    length: rand(90, 170),
  })

  if (meteors.length > 5) meteors.shift()
  if (ripples.length > 6) ripples.shift()
}

    function drawNebula() {
     const parallaxX =
  pointer.active && !reducedMotion.matches
    ? (pointer.x / width - 0.5) * -28
    : 0

const parallaxY =
  pointer.active && !reducedMotion.matches
    ? (pointer.y / height - 0.5) * -20
    : 0

const driftX =
  parallaxX +
  (reducedMotion.matches ? 0 : Math.sin(elapsed * 0.13) * width * 0.045)

const driftY =
  parallaxY +
  (reducedMotion.matches ? 0 : Math.cos(elapsed * 0.1) * height * 0.025)
      const base = ctx.createRadialGradient(
        width * 0.53 + driftX,
        height * 0.43 + driftY,
        0,
        width * 0.53 + driftX,
        height * 0.43 + driftY,
        Math.max(width, height) * 0.78,
      )
      base.addColorStop(0, 'rgba(83, 45, 119, 0.27)')
      base.addColorStop(0.35, 'rgba(47, 30, 79, 0.17)')
      base.addColorStop(0.72, 'rgba(19, 14, 31, 0.1)')
      base.addColorStop(1, '#05040b')

      ctx.fillStyle = base
      ctx.fillRect(0, 0, width, height)

      // Separate cloud layers add depth and gentle movement.
      const clouds = [
        { x: 0.2, y: 0.29, r: 0.42, c: 'rgba(134, 77, 203, 0.09)', speed: 0.12 },
        { x: 0.82, y: 0.33, r: 0.36, c: 'rgba(235, 172, 91, 0.075)', speed: -0.1 },
        { x: 0.51, y: 0.78, r: 0.4, c: 'rgba(91, 73, 177, 0.075)', speed: 0.075 },
      ]

      for (const cloud of clouds) {
        const x = width * cloud.x + Math.sin(elapsed * cloud.speed) * width * 0.035
        const y = height * cloud.y + Math.cos(elapsed * cloud.speed) * height * 0.025
        const radius = Math.max(width, height) * cloud.r
        const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
        gradient.addColorStop(0, cloud.c)
        gradient.addColorStop(1, 'rgba(5, 4, 11, 0)')
        ctx.fillStyle = gradient
        ctx.fillRect(0, 0, width, height)
      }
    }

    function drawPlanets() {
      for (const planet of planets) {
        const px = pointer.active ? (pointer.x - width / 2) * planet.depth : 0
        const py = pointer.active ? (pointer.y - height / 2) * planet.depth : 0
        const x = planet.x + px
        const y = planet.y + py

        const halo = ctx.createRadialGradient(x, y, planet.radius * 0.3, x, y, planet.radius * 2.6)
        halo.addColorStop(0, planet.tint)
        halo.addColorStop(1, 'rgba(5, 4, 11, 0)')
        ctx.fillStyle = halo
        ctx.beginPath()
        ctx.arc(x, y, planet.radius * 2.6, 0, Math.PI * 2)
        ctx.fill()

        const sphere = ctx.createRadialGradient(
          x - planet.radius * 0.42,
          y - planet.radius * 0.45,
          planet.radius * 0.04,
          x,
          y,
          planet.radius,
        )
        sphere.addColorStop(0, '#655579')
        sphere.addColorStop(0.45, '#29213c')
        sphere.addColorStop(0.82, '#100d1a')
        sphere.addColorStop(1, '#05040b')

        ctx.fillStyle = sphere
        ctx.beginPath()
        ctx.arc(x, y, planet.radius, 0, Math.PI * 2)
        ctx.fill()

        ctx.strokeStyle = 'rgba(241, 194, 111, 0.22)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.arc(x, y, planet.radius, -Math.PI * 0.85, Math.PI * 0.18)
        ctx.stroke()
      }
    }

   

function drawGalaxyParticles(dt) {
  const cx = width * 0.5
  const cy = height * 0.47
  const maxRadius = Math.min(width * 0.48, height * 0.58)

  // Warm, luminous core with a violet outer glow.
  const coreRadius = Math.min(width, height) * 0.22
  const core = ctx.createRadialGradient(
    cx, cy, 0,
    cx, cy, coreRadius,
  )

  core.addColorStop(0, 'rgba(255, 246, 222, 0.96)')
  core.addColorStop(0.035, 'rgba(255, 215, 151, 0.8)')
  core.addColorStop(0.12, 'rgba(255, 177, 111, 0.34)')
  core.addColorStop(0.38, 'rgba(189, 124, 255, 0.13)')
  core.addColorStop(1, 'rgba(5, 4, 11, 0)')

  ctx.fillStyle = core
  ctx.fillRect(cx - coreRadius, cy - coreRadius, coreRadius * 2, coreRadius * 2)

  for (const p of galaxyDust) {
    if (!reducedMotion.matches) p.angle += p.orbit * dt

    // Spiral pitch makes the arms curve outward instead of forming rings.
    const a = p.angle + p.radius / maxRadius * 3.4
    const ellipse = 0.64 + p.depth * 0.08
const parallaxX =
  pointer.active && !reducedMotion.matches
    ? (pointer.x / width - 0.5) * -32 * p.depth
    : 0

const parallaxY =
  pointer.active && !reducedMotion.matches
    ? (pointer.y / height - 0.5) * -24 * p.depth
    : 0

let x = cx + Math.cos(a) * p.radius + parallaxX
let y = cy + Math.sin(a) * p.radius * ellipse + parallaxY

    // Mouse attraction: nearby dust bends around the cursor.
    if (pointer.active && !reducedMotion.matches) {
      const dx = pointer.x - x
      const dy = pointer.y - y
      const distance = Math.hypot(dx, dy)

      if (distance > 1 && distance < 190) {
        const force = Math.pow(1 - distance / 190, 2) * 27
        x += (dx / distance) * force
        y += (dy / distance) * force
      }
    }

    const twinkle =
      0.68 + Math.sin(elapsed * 1.8 + p.phase) * 0.32

    ctx.globalAlpha = p.alpha * twinkle * p.depth

    if (p.violet) {
      ctx.fillStyle = '#c5a5ff'
    } else {
      ctx.fillStyle = p.gold ? '#ffd993' : '#f3edff'
    }

    if (p.bright) {
      ctx.shadowBlur = p.dust ? 13 : 8
      ctx.shadowColor = p.gold ? '#ffca79' : '#c5a5ff'
    } else {
      ctx.shadowBlur = 0
    }

    ctx.beginPath()
    ctx.arc(x, y, p.size * (p.bright ? 1.4 : 1), 0, Math.PI * 2)
    ctx.fill()

    // Fine dust creates soft, cloudy lanes within the spiral arms.
    if (p.dust && p.radius > 45 && p.bright && !reducedMotion.matches) {
      ctx.globalAlpha *= 0.18
      ctx.fillStyle = '#b58af7'
      ctx.beginPath()
      ctx.arc(x, y, p.size * 4.5, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  ctx.globalAlpha = 1
  ctx.shadowBlur = 0

  // Independent distant stars give the scene depth.
  for (const star of stars) {
    const twinkle =
      0.62 + Math.sin(elapsed * star.speed + star.phase) * 0.35

    ctx.globalAlpha = star.alpha * twinkle
    ctx.fillStyle = star.gold ? '#f4ce8a' : '#e9e3ff'
    ctx.beginPath()
    ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
    ctx.fill()
  }

  ctx.globalAlpha = 1
}

    function drawMeteors(dt) {
      if (!reducedMotion.matches && Math.random() < 0.012 && meteors.length < 3) {
        const fromLeft = Math.random() < 0.5
        meteors.push({
  x: fromLeft ? rand(-80, width * 0.35) : rand(width * 0.55, width + 80),
  y: rand(-80, height * 0.48),
  vx: fromLeft ? rand(260, 430) : rand(-430, -260),
  vy: rand(190, 340),
  age: 0,
  life: rand(0.9, 1.55),
  length: rand(130, 240),
})
      }

      meteors = meteors.filter(meteor => meteor.age < meteor.life)


      // During the opening sequence, occasional meteors dive into the forming logo.
if (
  !reducedMotion.matches &&
  elapsed < 4.4 &&
  logoParticles.length > 0 &&
  Math.random() < 0.065 &&
  meteors.length < 5
) {
  const target =
    logoParticles[Math.floor(Math.random() * logoParticles.length)]

  const startX = rand(0, width)
  const startY = rand(-height * 0.25, height * 0.12)
  const dx = target.centerX - startX
  const dy = target.centerY - startY
  const distance = Math.hypot(dx, dy) || 1
  const speed = rand(650, 950)

  meteors.push({
    x: startX,
    y: startY,
    vx: (dx / distance) * speed,
    vy: (dy / distance) * speed,
    age: 0,
    life: Math.min(1.1, distance / speed),
    length: rand(100, 190),
  })
}

      for (const meteor of meteors) {
        meteor.age += dt
        meteor.x += meteor.vx * dt
        meteor.y += meteor.vy * dt

        const fade = Math.sin(Math.PI * meteor.age / meteor.life)
        const length = meteor.length
        const norm = Math.hypot(meteor.vx, meteor.vy) || 1
        const tailX = meteor.x - (meteor.vx / norm) * length
        const tailY = meteor.y - (meteor.vy / norm) * length

        const trail = ctx.createLinearGradient(meteor.x, meteor.y, tailX, tailY)
        trail.addColorStop(0, `rgba(255, 247, 216, ${fade})`)
        trail.addColorStop(0.18, `rgba(244, 191, 100, ${fade * 0.8})`)
        trail.addColorStop(1, 'rgba(171, 116, 240, 0)')

        ctx.strokeStyle = trail
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(meteor.x, meteor.y)
        ctx.lineTo(tailX, tailY)
        ctx.stroke()

        ctx.fillStyle = `rgba(255, 244, 212, ${fade})`
        ctx.beginPath()
        ctx.arc(meteor.x, meteor.y, 1.7, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    function drawConstellations() {
      if (!pointer.active) return

      const nearby = stars
        .map(star => ({ star, distance: Math.hypot(star.x - pointer.x, star.y - pointer.y) }))
        .filter(item => item.distance < 105)
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 9)

      ctx.lineWidth = 0.75

      for (let i = 0; i < nearby.length - 1; i++) {
        const a = nearby[i]
        const b = nearby[i + 1]
        if (Math.hypot(a.star.x - b.star.x, a.star.y - b.star.y) > 75) continue

        ctx.strokeStyle = `rgba(241, 200, 122, ${0.22 * (1 - a.distance / 120)})`
        ctx.beginPath()
        ctx.moveTo(a.star.x, a.star.y)
        ctx.lineTo(b.star.x, b.star.y)
        ctx.stroke()
      }
    }

    function drawRipples(dt) {
      ripples = ripples.filter(ripple => ripple.age < ripple.life)

      for (const ripple of ripples) {
        ripple.age += dt
        const progress = ripple.age / ripple.life
        const radius = progress * Math.min(width, height) * 0.19
        const alpha = 1 - progress

        for (let ring = 0; ring < 3; ring++) {
          ctx.beginPath()
          ctx.arc(ripple.x, ripple.y, Math.max(1, radius - ring * 13), 0, Math.PI * 2)
          ctx.strokeStyle = `rgba(244, 199, 110, ${alpha * (0.45 - ring * 0.1)})`
          ctx.lineWidth = ring === 0 ? 1.5 : 0.8
          ctx.stroke()
        }

        // Small particles shoot outward from the click.
        if (progress < 0.13) {
          for (let i = 0; i < 3; i++) {
            const angle = rand(0, Math.PI * 2)
            const r = radius + rand(2, 18)
            ctx.fillStyle = `rgba(255, 229, 170, ${alpha})`
            ctx.beginPath()
            ctx.arc(
              ripple.x + Math.cos(angle) * r,
              ripple.y + Math.sin(angle) * r,
              rand(0.5, 1.7),
              0,
              Math.PI * 2,
            )
            ctx.fill()
          }
        }
      }
    }

    function drawLogo(dt) {
      const gather = Math.min(1, elapsed / 4)
      const gatherEase = gather * gather * (3 - 2 * gather)
      const travel = Math.max(0, Math.min(1, (elapsed - 4) / 1.5))
      const travelEase = travel * travel * (3 - 2 * travel)

      for (const particle of logoParticles) {
        const formedX = particle.startX + (particle.centerX - particle.startX) * gatherEase
        const formedY = particle.startY + (particle.centerY - particle.startY) * gatherEase
        const x = formedX + (particle.endX - formedX) * travelEase
        const y = formedY + (particle.endY - formedY) * travelEase

        const fade = elapsed < 4.95
          ? 1
          : Math.max(0, 1 - (elapsed - 4.95) / 0.65)

        if (fade <= 0) continue

        const shimmer = 0.75 + Math.sin(elapsed * 2.8 + particle.phase) * 0.25
        ctx.globalAlpha = fade * shimmer
        ctx.fillStyle = particle.gold ? '#f2c96f' : '#fff1d3'
        ctx.shadowBlur = 4
        ctx.shadowColor = particle.gold ? '#f2c96f' : '#fff1d3'

        ctx.beginPath()
        ctx.arc(x, y, particle.size, 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.globalAlpha = 1
      ctx.shadowBlur = 0

      if (!logoReady && elapsed >= 5.5) {
        logoReady = true
        host?.classList.add('cosmic-logo-ready')
      }
    }

    function draw(time) {
      frameId = requestAnimationFrame(draw)

      const dt = Math.min((time - (previousTime || time)) / 1000, 0.033)
      previousTime = time
      elapsed += dt

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.fillStyle = '#05040b'
      ctx.fillRect(0, 0, width, height)

      drawNebula()
      drawGalaxyParticles(dt)
      drawConstellations()
      drawMeteors(dt)
      drawRipples(dt)
      drawLogo(dt)
    }
host.addEventListener('pointermove', pointerMove, { passive: true })
host.addEventListener('pointerleave', pointerLeave)
host.addEventListener('click', pointerClick)




    resizeObserver = new ResizeObserver(resize)
    resizeObserver.observe(canvas)
    resize()

    frameId = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(frameId)
      resizeObserver?.disconnect()
     host.removeEventListener('pointermove', pointerMove)
host.removeEventListener('pointerleave', pointerLeave)
host.removeEventListener('click', pointerClick)




      host?.classList.remove('cosmic-logo-ready')
    }
  }, [])

  return <canvas ref={canvasRef} className="cosmic-galaxy-canvas" aria-hidden="true" />
}
