// src/supabase.js
import { createClient } from '@supabase/supabase-js'

const rawSupabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY

// Accept the project root URL, and normalize an accidental /rest/v1 suffix.
const supabaseUrl = rawSupabaseUrl?.replace(/\/+$/, '').replace(/\/rest\/v1$/, '')

if (!supabaseUrl || !supabasePublishableKey) {
  console.error(
    'Supabase configuration is missing. Check VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in your root .env file, then restart Vite.'
  )
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabasePublishableKey || 'placeholder-publishable-key'
)
