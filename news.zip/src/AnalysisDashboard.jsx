
import React, { useMemo } from 'react';
import './AnalysisDashboard.css';

const improvementAreas = [
  {
    icon: '◷',
    title: 'Time Management',
    description: 'Protect a small, repeatable block of time each day.',
    color: 'gold',
  },
  {
    icon: '♡',
    title: 'Healthy Habits',
    description: 'Build a routine that supports your energy and wellbeing.',
    color: 'rose',
  },
  {
    icon: '✧',
    title: 'Motivation',
    description: 'Connect daily actions to the reason you chose this goal.',
    color: 'violet',
  },
  {
    icon: '↗',
    title: 'Your Focus Areas',
    description: 'Turn your priorities into practical daily actions.',
    color: 'blue',
  },
];

function readFocusAreas(setup) {
  const value = setup?.focus ?? setup?.focusAreas ?? [];
  return Array.isArray(value) ? value : value ? [value] : [];
}

function getProfileCompleteness(setup) {
  const fields = [
    setup?.name,
    setup?.username,
    setup?.gender,
    setup?.age,
    setup?.primaryGoal ?? setup?.goal,
    setup?.motivation,
    readFocusAreas(setup).length,
    setup?.obstacles,
    setup?.level,
    setup?.time,
    setup?.referral,
    setup?.goalHorizon,
  ];

  const completed = fields.filter((value) => {
    if (Array.isArray(value)) return value.length > 0;
    return value !== undefined && value !== null && String(value).trim() !== '';
  }).length;

  return Math.round((completed / fields.length) * 100);
}

export default function AnalysisDashboard({
  setup = {},
  onBack = () => {},
  onViewPlan = () => {},
  onSignIn = () => {},
}) {
  const focusAreas = readFocusAreas(setup);

  const completeness = useMemo(
    () => getProfileCompleteness(setup),
    [setup]
  );

  const displayName = setup?.name?.trim() || 'there';
  const goal = setup?.primaryGoal || setup?.goal || 'your personal goals';

  return (
    <main className="atelier-analysis">
      <div className="atelier-analysis-stars" aria-hidden="true" />

      <header className="atelier-analysis-top">
        <a
          className="atelier-analysis-brand"
          href="#analysis"
          onClick={(event) => event.preventDefault()}
          aria-label="atelier"
        >
          atelier <span>✦</span>
        </a>

        <div className="atelier-analysis-progress" aria-label="Analysis complete">
          <span className="is-complete" />
          <span className="is-complete" />
          <span className="is-complete" />
          <span className="is-complete" />
          <span className="is-complete" />
        </div>

        <button
          type="button"
          className="atelier-sign-in"
          onClick={onSignIn}
        >
          Sign In
        </button>
      </header>

      <section className="atelier-analysis-heading" id="analysis">
        <div className="atelier-eyebrow">
          <span>✦</span> ANALYSIS COMPLETE <span>✦</span>
        </div>

        <h1>
          Here’s your <em>starting point.</em>
        </h1>

        <p>
          Based on your answers, let’s identify your priorities and shape
          a plan that fits your real life.
        </p>
      </section>

      <section className="atelier-analysis-grid">
        <article className="atelier-glass-card atelier-rating-card">
          <h2><span className="atelier-heading-icon">☆</span> Overall Rating</h2>

          <div
            className="atelier-rating-ring"
            style={{ '--rating-progress': `${completeness}%` }}
            role="img"
            aria-label={`${completeness}% profile completeness`}
          >
            <div className="atelier-rating-inner">
              <div className="atelier-rating-number">
                <strong>{Math.round(completeness / 10)}</strong>
                <span>/10</span>
              </div>
              <small>Profile completeness</small>
            </div>
          </div>

          <p className="atelier-rating-copy">
            {displayName}, your starting point is taking shape. Use your
            personal plan to build consistent habits and make progress
            one step at a time.
          </p>

          <div className="atelier-rating-caption">
            <span>✦</span> Your journey, your pace.
          </div>
        </article>

        <article className="atelier-glass-card atelier-profile-card">
          <h2><span className="atelier-heading-icon">✧</span> Your Personal Blueprint</h2>

          <div className="atelier-profile-stats">
            <div className="atelier-stat">
              <strong>{completeness}%</strong>
              <span>Answers completed</span>
              <div className="atelier-stat-track">
                <span style={{ width: `${completeness}%` }} />
              </div>
            </div>

            <div className="atelier-stat">
              <strong>{focusAreas.length}</strong>
              <span>Selected focus areas</span>
              <div className="atelier-stat-track">
                <span
                  style={{
                    width: `${Math.min(focusAreas.length / 6, 1) * 100}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <p className="atelier-profile-note">
            These figures describe your answers and selected priorities.
            They are not a scientific measurement of ability or future success.
          </p>

          <div className="atelier-insight-box">
            <span className="atelier-insight-icon">✦</span>

            <div>
              <strong>Your next step</strong>
              <p>
                Start with one manageable action that supports {goal}.
                Consistency matters more than trying to change everything
                at once.
              </p>
            </div>
          </div>

          <div className="atelier-profile-tags">
            <span>Personal goals</span>
            <span>Daily routines</span>
            <span>Real progress</span>
          </div>
        </article>

        <article className="atelier-glass-card atelier-improvements-card">
          <h2>
            <span className="atelier-heading-icon">↗</span>
            Key Areas for Improvement
          </h2>

          <div className="atelier-improvement-list">
            {improvementAreas.map((area) => (
              <div className="atelier-improvement-item" key={area.title}>
                <span className={`atelier-area-icon ${area.color}`}>
                  {area.icon}
                </span>

                <div className="atelier-area-copy">
                  <strong>{area.title}</strong>
                  <p>{area.description}</p>
                </div>

                <span className="atelier-area-arrow" aria-hidden="true">
                  →
                </span>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="atelier-potential-banner">
        <div className="atelier-banner-glow" aria-hidden="true" />

        <div className="atelier-banner-star" aria-hidden="true">✧</div>

        <div className="atelier-banner-content">
          <div className="atelier-eyebrow">✦ YOUR PERSONAL BLUEPRINT</div>

          <h2>
            Your next chapter starts with <em>one clear step.</em>
          </h2>

          <p>
            Bring your goals, available time and everyday challenges
            together in a plan that feels achievable in real life.
          </p>

          <div className="atelier-banner-features">
            <div>
              <span>◎</span>
              <div>
                <strong>Clear Goals</strong>
                <small>Personalized for you</small>
              </div>
            </div>

            <div>
              <span>▥</span>
              <div>
                <strong>Structured Plan</strong>
                <small>Step-by-step guidance</small>
              </div>
            </div>

            <div>
              <span>♕</span>
              <div>
                <strong>Real Progress</strong>
                <small>Track your growth</small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="atelier-analysis-actions">
        <button
          type="button"
          className="atelier-back-button"
          onClick={onBack}
        >
          <span>←</span> Back to analysis
        </button>

        <button
          type="button"
          className="atelier-plan-button"
          onClick={onViewPlan}
        >
          View My Plan <span>→</span>
        </button>
      </footer>

      <div className="atelier-analysis-footer">
        <span>atelier.</span>
        <span>ALIGN · PLAN · GROW</span>
        <span>Made for your real life.</span>
      </div>
    </main>
  );
}
